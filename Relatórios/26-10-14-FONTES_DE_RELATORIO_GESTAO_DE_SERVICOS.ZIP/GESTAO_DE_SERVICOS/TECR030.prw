#include "Rwmake.ch"
#include "Protheus.ch"
#Include 'TOPCONN.ch'
#Include 'TECR030.ch'

Static cAutoPerg := "TECR030"
//-------------------------------------------------------------------
/*/{Protheus.doc} TECR030
Imprime o relatorio de Manutencao de Agendas

@author filipe.goncalves
@since 21/01/2016
@version P12.1.11
/*/
//-------------------------------------------------------------------
Function TECR030()
	local oReport          
	Private cPerg	:= "TECR030"
	
	//������������������������������������������������������������������������Ŀ
 	//� PARAMETROS                                                             �
 	//� MV_PAR01 : Data de ?                                                   �
 	//� MV_PAR02 : Data ate?                                                   �
 	//� MV_PAR03 : Atendente de ?                                              �
 	//� MV_PAR04 : Atendente ate ?                                             �
 	//� MV_PAR05 : Local de ?                                       		   �
 	//� MV_PAR06 : Local ate ?                                                 �
 	//� MV_PAR07 : Motivo de ?                                                 �
 	//� MV_PAR08 : Motivo ate ?                                                �
 	//�������������������������������������������������������������������������� 
 	
 	If !Pergunte(cPerg,.T.)
		Return
	EndIf   
	
	oReport := ReportDef()
	oReport:PrintDialog()
Return

//-------------------------------------------------------------------------------------
/*/{Protheus.doc} reportDef
Monta as defini�oes do relatorio de Recursos (Atendentes) N�o-Alocados.
@author filipe.goncalves
@since 21/01/2016
@version P12.1.11
@return  Nil
/*/
//-------------------------------------------------------------------------------------
Static Function ReportDef()
	Local cTitulo 	:= STR0001
	Local oReport
	Local oSection1
	
	If TYPE("cPerg") == "U"
		cPerg	:= "TECR030"
	EndIf
	
	oReport 	:= TReport():New(cPerg, cTitulo, cPerg , {|oReport| PrintReport(oReport)},STR0002)
	oSection1 := TRSection():New(oReport,"Agenda de Atendentes",{"ABB","ABS","SRA"})
	
	oReport:ShowHeader()
	oReport:SetPortrait()                              
	oReport:SetTotalInLine(.F.)
	oSection1:SetTotalInLine(.F.)

	TRCell():New(oSection1, STR0011 , "ABS", STR0026 ,PesqPict('SRA',"RA_NOME")		,TamSX3("RA_NOME")[1]	,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0012	, "SRA", STR0012 ,PesqPict('SRA',"RA_CIC")		,TamSX3("RA_CIC")[1]	,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0013	, "ABS", STR0027 ,PesqPict('SRA',"RA_NOME")		,TamSX3("RA_NOME")[1]	,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0014	, "SRA", STR0028 ,PesqPict('SRA',"RA_CIC")		,TamSX3("RA_CIC")[1]	,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0015	, "ABS", STR0029 ,"@!"							,23					    ,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0016	, "ABB", STR0030 ,PesqPict('ABB',"ABB_DTINI")	,15						,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():New(oSection1, STR0017	, "ABB", STR0031 ,PesqPict('ABB',"ABB_HRINI")	,09						,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0018	, "ABB", STR0032 ,PesqPict('ABB',"ABB_DTFIM")	,15						,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0019	, "ABB", STR0033 ,PesqPict('ABB',"ABB_HRFIM")	,11						,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0020	, "ABS", STR0034 ,PesqPict('ABS',"ABS_LOCAL")	,TamSX3("ABS_LOCAL")[1]	,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0021	, "ABS", STR0035 ,PesqPict('ABS',"ABS_DESCRI")	,TamSX3("ABS_DESCRI")[1],/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0022	, "ABS", STR0036 ,PesqPict('ABS',"ABS_DESCRI")	,TamSX3("ABS_DESCRI")[1],/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0023	, "ABS", STR0037 ,PesqPict('ABS',"ABS_DESCRI")	,15						,/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0024	, "ABS", STR0038 ,PesqPict('ABS',"ABS_DESCRI")	,TamSX3("ABS_DESCRI")[1],/*lPixel*/,/*{|| code-block de impressao }*/)
	TRCell():new(oSection1, STR0025	, "ABS", STR0025 ,PesqPict('ABS',"ABS_DESCRI")	,TamSX3("ABS_DESCRI")[1],/*lPixel*/,/*{|| code-block de impressao }*/)

	oSection1:Cell(STR0011):SetAlign("LEFT")
	oSection1:Cell(STR0012):SetAlign("LEFT")
	oSection1:Cell(STR0015):SetAlign("LEFT")
	oSection1:Cell(STR0016):SetAlign("LEFT")
	oSection1:Cell(STR0017):SetAlign("LEFT")
	oSection1:Cell(STR0018):SetAlign("LEFT")
	oSection1:Cell(STR0019):SetAlign("LEFT")
	oSection1:Cell(STR0020):SetAlign("LEFT")
	oSection1:Cell(STR0021):SetAlign("LEFT")
	oSection1:Cell(STR0022):SetAlign("LEFT")
	oSection1:Cell(STR0023):SetAlign("LEFT")
	oSection1:Cell(STR0013):SetAlign("LEFT")
	oSection1:Cell(STR0014):SetAlign("LEFT")

Return (oReport)

//-------------------------------------------------------------------------------------
/*/{Protheus.doc} PrintReport
Pinta o Relatorio de Manuten��o de Agendas

@author filipe.goncalves
@since 21/01/2016
@version P12.1.11
@return  Nil
/*/
//-------------------------------------------------------------------------------------
Static Function PrintReport(oReport)
	Local oSection1 := oReport:Section(1)
	Local cAlias    := ""
	Local cDia      := ""
	Local cQtdHora  := ""
	Local cQuery    := ""
	Local cSubCpf   := ""
	Local cSubMat   := ""
	Local cSubNom   := ""
	Local lMultFil  := SuperGetMV("MV_GSMSFIL",,.F.)
	Local nDia      := 0
	Local nNum      := 1
	Local oQuery    := Nil

	cQuery := "SELECT ABS.ABS_DESCRI, "
	cQuery +=        "ABS.ABS_LOCAL, "
	cQuery +=        "ABS.ABS_DESCRI, "
	cQuery +=        "ABS.ABS_CCUSTO, "
	cQuery +=        "ABB.ABB_DTINI, "
	cQuery +=        "ABB.ABB_HRINI, "
	cQuery +=        "ABB.ABB_HRFIM, "
	cQuery +=        "ABB.ABB_DTFIM, "
	cQuery +=        "AA1.AA1_NOMTEC, "
	cQuery +=        "ABR.ABR_MOTIVO, "
	cQuery +=        "ABR.ABR_CODSUB, "
	If Trim(Upper(TcGetDb())) $ "ORACLE,POSTGRES"
		cQuery += "CAST(SUBSTR(ABR_OBSERV,2047,1) as varchar(2047)) ABR_OBSERV, "
	Else
		cQuery += "COALESCE(CONVERT(VARCHAR(2047), CONVERT(VARBINARY(2047),ABR_OBSERV)),' ') AS ABR_OBSERV, "
	EndIf
	cQuery +=        "SRA.RA_CIC "
	cQuery += "FROM   ? ABS "
	cQuery +=        "INNER JOIN ? ABB "
	If lMultFil
		cQuery +=            "ON ? "
	Else
		cQuery +=            "ON ABB.ABB_FILIAL = ? "		
	EndIf
	cQuery +=                   "AND ABB.ABB_LOCAL = ABS.ABS_LOCAL "	
	cQuery +=                   "AND ABB.ABB_DTINI BETWEEN ? AND ? "	
	cQuery +=                   "AND ABB.ABB_CODTEC BETWEEN ? AND ? "
    cQuery +=                   "AND ABB.D_E_L_E_T_ = ' ' "
	cQuery +=        "INNER JOIN ? AA1 "	
    cQuery +=                "ON AA1.AA1_CODTEC = ABB.ABB_CODTEC "
    cQuery +=                   "AND AA1.D_E_L_E_T_ = ' ' "
	cQuery +=        "INNER JOIN ? ABR "
	If lMultFil
		cQuery +=            "ON ? "
	Else
		cQuery +=            "ON ABR.ABR_FILIAL = ? "		
	EndIf
	cQuery +=                   "AND ABR.ABR_AGENDA = ABB.ABB_CODIGO "	
	cQuery +=                   "AND ABR.ABR_MOTIVO BETWEEN ? AND ? "
    cQuery +=                   "AND ABR.D_E_L_E_T_ = ' ' "
	cQuery +=        "INNER JOIN ? SRA "
	If lMultFil	
		cQuery +=            "ON ? "
	Else
    	cQuery +=            "ON RA_FILIAL = ? "
	EndIf
	cQuery +=                   "AND SRA.RA_FILIAL = AA1.AA1_FUNFIL "		
	cQuery +=                   "AND SRA.RA_MAT = AA1.AA1_CDFUNC "		
    cQuery +=                   "AND SRA.D_E_L_E_T_ = ' ' "		
	If lMultFil
		cQuery += "WHERE ? "
	Else
		cQuery += "WHERE ABS.ABS_FILIAL = ? "		
	EndIf
	cQuery +=           "AND ABS.ABS_LOCAL BETWEEN ? AND ? "
    cQuery +=           "AND ABS.D_E_L_E_T_ = ' ' "
	cQuery += "ORDER BY ABB.ABB_CODTEC, " 
	cQuery +=          "ABB.ABB_DTINI " 

	nNum := 1
    cQuery := ChangeQuery(cQuery)
    oQuery := FwExecStatement():New(cQuery)

	oQuery:SetUnsafe(nNum++, RetSqlName("ABS"))
	oQuery:SetUnsafe(nNum++, RetSqlName("ABB"))
	If lMultFil
    	oQuery:SetUnsafe(nNum++, FWJoinFilial("ABB","ABS","ABB","ABS",.T.))
	Else
		oQuery:SetString(nNum++, xFilial("ABB"))
	EndIf
	oQuery:SetDate(nNum++, MV_PAR01)
	oQuery:SetDate(nNum++, MV_PAR02)
	oQuery:SetString(nNum++, MV_PAR03)
	oQuery:SetString(nNum++, MV_PAR04)
	oQuery:SetUnsafe(nNum++, RetSqlName("AA1"))
	oQuery:SetUnsafe(nNum++, RetSqlName("ABR"))
	If lMultFil
    	oQuery:SetUnsafe(nNum++, FWJoinFilial("ABR","ABB","ABR","ABB",.T.))
	Else
		oQuery:SetString(nNum++, xFilial("ABR"))
	EndIf
	oQuery:SetString(nNum++, MV_PAR07)
	oQuery:SetString(nNum++, MV_PAR08)
	oQuery:SetUnsafe(nNum++, RetSqlName("SRA"))
	If lMultFil
		oQuery:SetUnsafe(nNum++, FWJoinFilial("SRA","AA1","SRA","AA1",.T.))
	Else
		oQuery:SetString(nNum++, xFilial("SRA"))		
	EndIf
	If lMultFil
		oQuery:SetUnsafe(nNum++, FWJoinFilial("ABS","ABB","ABS","ABB",.T.))
	Else
		oQuery:SetString(nNum++, xFilial("ABS"))
	EndIf
	oQuery:SetString(nNum++, MV_PAR05)
	oQuery:SetString(nNum++, MV_PAR06)
	
	cAlias := oQuery:OpenAlias()
	oQuery:Destroy()
    FwFreeObj(oQuery)
	
	//Monta a primeira secao do relatorio
	oSection1:Init()
	oSection1:SetHeaderSection(.T.)

	//Para cada registro de manuten��o, pinta uma linha no relatorio
	While (cAlias)->(!Eof())

		//Define o dia da semana
		nDia := DOW(SToD((cAlias)->ABB_DTINI))
		If nDia == 1
			cDia := STR0039 //Domingo
		ElseIf nDia == 2
			cDia := STR0040 //Segunda
		ElseIf nDia == 3
			cDia := STR0041 //Ter�a
		ElseIf nDia == 4
			cDia := STR0042 //Quarta
		ElseIf nDia == 5
			cDia := STR0043 //Quinta
		ElseIf nDia == 6
			cDia := STR0044 //Sexta
		ElseIf nDia == 7
			cDia := STR0045 //S�bado
		EndIf

		//Calcula a quantidade de horas trabalhadas
		If TecConvHr((cAlias)->ABB_HRINI) < TecConvHr((cAlias)->ABB_HRFIM)
			cQtdHora := Left(ElapTime((cAlias)->ABB_HRINI+":00", (cAlias)->ABB_HRFIM+":00"), 5)
		ElseIf TecConvHr((cAlias)->ABB_HRINI) > TecConvHr((cAlias)->ABB_HRFIM)
			cQtdHora := Left(ElapTime((cAlias)->ABB_HRFIM+":00", (cAlias)->ABB_HRINI+":00"), 5)
		Else
			cQtdHora := "00:00"
		EndIf

		//Informacoes do Substituto
		cSubNom := ""
		cSubCpf := ""
		cSubMat := ""
		If !(Empty((cAlias)->ABR_CODSUB))
			dbSelectArea('AA1')
			AA1->(dbSetOrder(1))
			If AA1->(dbSeek(xFilial('AA1') + (cAlias)->ABR_CODSUB ))
				cSubMat := AA1->AA1_CDFUNC
				dbSelectArea('SRA')
				SRA->(dbSetOrder(1))
				If SRA->(dbSeek(xFilial('SRA') + cSubMat ))
					cSubNom := alltrim(SRA->RA_NOME)
					cSubCpf := alltrim(SRA->RA_CIC)
				EndIf
			EndIf
		EndIf

		//Imprime os dados
		oSection1:Cell(STR0011):SetValue((cAlias)->AA1_NOMTEC)
		oSection1:Cell(STR0012):SetValue((cAlias)->RA_CIC)
		oSection1:Cell(STR0015):SetValue(cDia)
		oSection1:Cell(STR0016):SetValue(StoD((cAlias)->ABB_DTINI))
		oSection1:Cell(STR0017):SetValue((cAlias)->ABB_HRINI)
		oSection1:Cell(STR0018):SetValue(StoD((cAlias)->ABB_DTFIM))
		oSection1:Cell(STR0019):SetValue((cAlias)->ABB_HRFIM)
		oSection1:Cell(STR0020):SetValue((cAlias)->ABS_LOCAL)
		oSection1:Cell(STR0021):SetValue(AllTrim((cAlias)->ABS_DESCRI))
		oSection1:Cell(STR0022):SetValue(AllTrim((cAlias)->ABS_CCUSTO))
		oSection1:Cell(STR0023):SetValue(AllTrim(cQtdHora))
		oSection1:Cell(STR0024):SetValue(AllTrim(POSICIONE("ABN",1,xFilial("ABN")+(cAlias)->ABR_MOTIVO,"ABN_DESC")))
		oSection1:Cell(STR0025):SetValue(AllTrim((cAlias)->ABR_OBSERV))
		oSection1:Cell(STR0013):SetValue(cSubNom)
		oSection1:Cell(STR0014):SetValue(cSubCpf)
		oSection1:PrintLine()

		//Botao Cancelar	
		If oReport:Cancel()
			Exit
		EndIf

		//Incrementa Regua de Processamento
		oReport:IncMeter()

		//Proximo Registro
		(cAlias)->(dbSkip())
	EndDo

	(cAlias)->(dbCloseArea())

	oSection1:Finish()

Return

//-------------------------------------------------------------------------------------
/*/{Protheus.doc} GetPergTRp
Retorna o nome do Pergunte utilizado no relat�rio
Fun��o utilizada na automa��o
@author Mateus Boiani
@since 31/10/2018
@return cAutoPerg, string, nome do pergunte
/*/
//-------------------------------------------------------------------------------------
Static Function GetPergTRp()

Return cAutoPerg
