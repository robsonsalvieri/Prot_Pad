/*=============================================================================
**  APP_CLIENT_DYNAMIC_LINK                                   EPSON Argentina
** ============================================================================= 
**  
**  Note:
**  -----
** 
**       Ms-Windows. how to compile:   cl app_client_dynamic_link.c
** 
**       Ms-Windows. how to compile:   cl app_client_dynamic_link.c -DEBUG
** 
** 
**       Linux. how to compile:              gcc -pthread app_client_dynamic_link.c -ldl -o app_client_dynamic_link
**
**       Linux. how to compile for debug:    gcc -g -pthread app_client_dynamic_link.c -ldl -o app_client_dynamic_link
**
**       Linux: how to enabled port usb:     sudo chmod 777 /dev/usb/lp0
**                                           sudo chmod 777 /dev/usb/lp1
** 
**       Linux: debugging:                   gdb  ./app_client_dynamic_link
** 
**                                           gdb  -tui  ./app_client_dynamic_link
** 
**===========================================================================*/


#define _APP_CLIENT_DYNAMIC_LINK_C_


/*-----------------------------------------------------------------------------
Include Area
-----------------------------------------------------------------------------*/
#ifdef __linux__
  #include <dlfcn.h>
#else
  #include <Windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*-----------------------------------------------------------------------------
Macros Area
-----------------------------------------------------------------------------*/
#ifdef __linux__
  #define GETPROCADDRESS( x ) dlsym( hDLL, x )
  #define STDCALL
#else
  #define GETPROCADDRESS( x ) GetProcAddress( hDLL, x )
  #define STDCALL __stdcall
#endif


/*-----------------------------------------------------------------------------
Local Typedef Area
-----------------------------------------------------------------------------*/

typedef int (STDCALL *LP_CONSULTAR_VERSION_DLL)( char *respuesta_descripcion, int respuesta_descripcion_largo_maximo, int *respuesta_mayor, int *respuesta_menor );
typedef int (STDCALL *LP_CONFIGURAR_VELOCIDAD)( int velocidad );
typedef int (STDCALL *LP_CONFIGURAR_PUERTO)( const char *puerto );
typedef int (STDCALL *LP_CONECTAR)( void  );
typedef int (STDCALL *LP_DESCONECTAR)( void  );
typedef int (STDCALL *LP_CANCELAR)( void  );
typedef int (STDCALL *LP_ENVIAR_COMANDO)( const char *comando );
typedef int (STDCALL *LP_IMPRIMIR_CIERRE_X)( void  );
typedef int (STDCALL *LP_IMPRIMIR_CIERRE_Z)( void  );
typedef int (STDCALL *LP_CARGAR_LOGO)( const char *nombre_de_archivo  );
typedef int (STDCALL *LP_ABRIR_COMPROBANTE)( int id_tipo_documento  );
typedef int (STDCALL *LP_ESTABLECER_FECHA_HORA)( const char *fecha_hora );
typedef int (STDCALL *LP_DESCARGARPERIODOPENDIENTE)( const char *directorio_de_descarga );

/*-----------------------------------------------------------------------------
Local Variables Area
-----------------------------------------------------------------------------*/
LP_CONSULTAR_VERSION_DLL ConsultarVersionDll;         
LP_CONFIGURAR_VELOCIDAD ConfigurarVelocidad;         
LP_CONFIGURAR_PUERTO ConfigurarPuerto;         
LP_CONECTAR Conectar;         
LP_DESCONECTAR Desconectar;         
LP_CANCELAR Cancelar;         
LP_ENVIAR_COMANDO EnviarComando;          
LP_IMPRIMIR_CIERRE_X ImprimirCierreX;          
LP_IMPRIMIR_CIERRE_Z ImprimirCierreZ;      
LP_CARGAR_LOGO CargarLogo;      
LP_ABRIR_COMPROBANTE AbrirComprobante;
LP_ESTABLECER_FECHA_HORA EstablecerFechaHora;
LP_DESCARGARPERIODOPENDIENTE DescargarPeriodoPendiente;

#ifdef __linux__
  void *hDLL;
#else
  HINSTANCE hDLL;               
#endif



/*-----------------------------------------------------------------------------
** Function Name : main
** Description   : none
** Notes         : none
-----------------------------------------------------------------------------*/
int main( int argc, char *argv[] )
{
  int error;

  /* load dll */
  #ifdef __linux__
	  hDLL = dlopen("./EpsonFiscalInterface.so", RTLD_LAZY );
  #else
    hDLL = LoadLibrary("EpsonFiscalInterface.dll");
  #endif

  /* check  */
  if (hDLL == NULL)
  {
    printf("Imposible cargar Dll.\n");
    return 1;
  }

  /* load pointers */
  ConsultarVersionDll = ( LP_CONSULTAR_VERSION_DLL ) GETPROCADDRESS( "ConsultarVersionDll" );         
  ConfigurarVelocidad = ( LP_CONFIGURAR_VELOCIDAD ) GETPROCADDRESS( "ConfigurarVelocidad" );         
  ConfigurarPuerto = ( LP_CONFIGURAR_PUERTO ) GETPROCADDRESS( "ConfigurarPuerto" );         
  Conectar = ( LP_CONECTAR ) GETPROCADDRESS( "Conectar" );         
  Desconectar = ( LP_DESCONECTAR ) GETPROCADDRESS( "Desconectar" );         
  Cancelar = ( LP_CANCELAR ) GETPROCADDRESS( "Cancelar" );         
  EnviarComando = ( LP_ENVIAR_COMANDO ) GETPROCADDRESS( "EnviarComando" );          
  ImprimirCierreX = ( LP_IMPRIMIR_CIERRE_X ) GETPROCADDRESS( "ImprimirCierreX" );          
  ImprimirCierreZ = ( LP_IMPRIMIR_CIERRE_Z ) GETPROCADDRESS( "ImprimirCierreZ" );          
  CargarLogo = ( LP_CARGAR_LOGO ) GETPROCADDRESS( "CargarLogo" );
  AbrirComprobante = ( LP_ABRIR_COMPROBANTE ) GETPROCADDRESS( "AbrirComprobante" );
  EstablecerFechaHora = ( LP_ESTABLECER_FECHA_HORA ) GETPROCADDRESS( "EstablecerFechaHora" );
  DescargarPeriodoPendiente = ( LP_DESCARGARPERIODOPENDIENTE ) GETPROCADDRESS( "DescargarPeriodoPendiente" );


  /* get DLL version */
  {
    char respuesta_descripcion[200 + 1];
    int respuesta_mayor;
    int respuesta_menor;

    ConsultarVersionDll( respuesta_descripcion, sizeof(respuesta_descripcion) - 1, &respuesta_mayor, &respuesta_menor );
    printf("Version: %s\n\r\n\r", respuesta_descripcion );
  }

  /* try connect with port  */
  error = ConfigurarVelocidad( 115200 ); 
  error = ConfigurarPuerto( "0" );
  error = Conectar();
  if (error)
  {
    /* message */
    printf("Imposible establecer conexion con el puerto.\n");

    /* free dll */
    #ifdef __linux__
      dlclose( hDLL );
    #else
      FreeLibrary(hDLL);       
    #endif

    /* bad exit */
    return 2;
  }

  /* sync date time from PC */
  EstablecerFechaHora( "" );

  /* cancel all */
  Cancelar();

  /* print X & Z */
  ImprimirCierreX();
  ImprimirCierreZ();

  /* descargar periodo pendiente */
  /* DescargarPeriodoPendiente("."); */

  /* send generic command */
  error = 0;
  error |= EnviarComando("0530|0000|x'00'x'01'|x'00'x'01'|0");
  error |= EnviarComando("0531|0000|x'A0'x'A0'x'A0'x'A0'x'A0'x'A0'x'A0'");
  error |= EnviarComando("0531|0000|x'A0'");
  error |= EnviarComando("0532|0000");
  printf( "Error 'EnviarComando()': %d\n\r", error );

  /* print open ticket */
  AbrirComprobante( 1 );
  Cancelar();

  /* print X & Z */
  ImprimirCierreX();
  ImprimirCierreZ();

  /* upload logo command  */
  error = CargarLogo( "logo_chico_horizontal_completo.png" );
  printf( "Error 'CargarLogo()': %d\n\r", error );

  /* print open ticket */
  AbrirComprobante( 1 );
  Cancelar();

  /* free dll */
  #ifdef __linux__
    dlclose( hDLL );
  #else
    FreeLibrary(hDLL);       
  #endif

  /* exit point */
  return error;
}
    
