﻿Imports System.Text
Imports System.Threading

Imports System.IO
Imports System.Security.Cryptography
Imports System.Security.Cryptography.Pkcs
Imports System.Security.Cryptography.X509Certificates


Public Class FormInit

    ' -----------------------------------------------------------------------------
    ' VERSION
    ' -----------------------------------------------------------------------------
    Const EXAMPLE_VERSION = "v.0007"

    '-----------------------------------------------------------------------------
    'Typedef from exported Prototypes of "EpsonFiscalInterface.h"
    '-----------------------------------------------------------------------------
    Private Declare Function ConfigurarVelocidad Lib "EpsonFiscalInterface.dll" (ByVal velocidad As Integer) As Integer
    Private Declare Function ConfigurarPuerto Lib "EpsonFiscalInterface.dll" (ByVal puerto As String) As Integer
    Private Declare Function Conectar Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function Desconectar Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function Cancelar Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ComenzarLog Lib "EpsonFiscalInterface.dll" (ByVal incluir_tramas_bajo_nivel As Boolean) As Integer
    Private Declare Function DetenerLog Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function PausarLog Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ReanudarLog Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ConsultarUltimoError Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ConsultarDescripcionDeError Lib "EpsonFiscalInterface.dll" (ByVal nro_error As Integer, ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarVersionDll Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer, ByRef mayor As Integer, ByRef menor As Integer) As Integer
    Private Declare Function ConsultarVersionEquipo Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer, ByRef mayor As Integer, ByRef menor As Integer) As Integer
    Private Declare Function ConsultarNumeroPuntoDeVenta Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarNumeroComprobanteUltimo Lib "EpsonFiscalInterface.dll" (ByVal tipo_de_comprobante As String, ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarNumeroComprobanteActual Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarTipoComprobanteActual Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarSubTotalBrutoComprobanteActual Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarSubTotalNetoComprobanteActual Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ConsultarEstado Lib "EpsonFiscalInterface.dll" (ByVal id_consulta As Integer, ByRef respuesta As Integer) As Integer
    Private Declare Function EstablecerEncabezado Lib "EpsonFiscalInterface.dll" (ByVal numero_encabezado As Integer, ByVal descripcion As String) As Integer
    Private Declare Function ConsultarEncabezado Lib "EpsonFiscalInterface.dll" (ByVal numero_encabezado As Integer, ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function EstablecerCola Lib "EpsonFiscalInterface.dll" (ByVal numero_cola As Integer, ByVal descripcion As String) As Integer
    Private Declare Function ConsultarCola Lib "EpsonFiscalInterface.dll" (ByVal numero_cola As Integer, ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function EstablecerFechaHora Lib "EpsonFiscalInterface.dll" (ByVal fecha_hora As String) As Integer
    Private Declare Function ConsultarFechaHora Lib "EpsonFiscalInterface.dll" (ByVal respuesta As StringBuilder, ByVal respuesta_largo_maximo As Integer) As Integer
    Private Declare Function ImprimirAuditoria Lib "EpsonFiscalInterface.dll" (ByVal id_modificador As Integer, ByVal desde As String, ByVal hasta As String) As Integer
    Private Declare Function Descargar Lib "EpsonFiscalInterface.dll" (ByVal desde As String, ByVal hasta As String, ByVal path As String) As Integer
    Private Declare Function DescargarPeriodoPendiente Lib "EpsonFiscalInterface.dll" (ByVal path As String) As Integer
    Private Declare Function ConfimarDescarga Lib "EpsonFiscalInterface.dll" (ByVal hasta As String) As Integer
    Private Declare Function ConsultarFechaPrimerJornadaPendiente Lib "EpsonFiscalInterface.dll" (ByVal respuesta_periodo_pendiente As StringBuilder, ByVal respuesta_periodo_pendiente_largo_maximo As Integer) As Integer
    Private Declare Function CargarDatosCliente Lib "EpsonFiscalInterface.dll" (ByVal nombre_o_razon_social1 As String, ByVal nombre_o_razon_social2 As String, ByVal domicilio1 As String, ByVal domicilio2 As String, ByVal domicilio3 As String, ByVal id_tipo_documento As Integer, ByVal numero_documento As String, ByVal id_responsabilidad_iva As Integer) As Integer
    Private Declare Function CargarComprobanteAsociado Lib "EpsonFiscalInterface.dll" (ByVal descripcion As String) As Integer
    Private Declare Function AbrirComprobante Lib "EpsonFiscalInterface.dll" (ByVal id_tipo_documento As Integer) As Integer
    Private Declare Function CargarTextoExtra Lib "EpsonFiscalInterface.dll" (ByVal descripcion As String) As Integer
    Private Declare Function ImprimirItem Lib "EpsonFiscalInterface.dll" (ByVal id_modificador As Integer, ByVal descripcion As String, ByVal cantidad As String, ByVal precio As String, ByVal id_tasa_iva As Integer, ByVal ii_id As Integer, ByVal ii_valor As String, ByVal id_codigo As Integer, ByVal codigo As String, ByVal codigo_unidad_matrix As String, ByVal codigo_unidad_medida As Integer) As Integer
    Private Declare Function ImprimirTextoLibre Lib "EpsonFiscalInterface.dll" (ByVal descripcion As String) As Integer
    Private Declare Function CargarAjuste Lib "EpsonFiscalInterface.dll" (ByVal id_modificador As Integer, ByVal descripcion As String, ByVal monto As String, ByVal id_tasa_iva As Integer, ByVal codigo_interno As String) As Integer
    Private Declare Function CargarOtrosTributos Lib "EpsonFiscalInterface.dll" (ByVal codigo_otros_tributos As Integer, ByVal descripcion As String, ByVal monto As String, ByVal id_tasa_iva As Integer) As Integer
    Private Declare Function CargarPago Lib "EpsonFiscalInterface.dll" (ByVal id_modificador As Integer, ByVal codigo_forma_pago As Integer, ByVal cantidad_cuotas As Integer, ByVal monto As String, ByVal descripción_cupones As String, ByVal descripcion As String, ByVal descripcion_extra1 As String, ByVal descripcion_extra2 As String) As Integer
    Private Declare Function ImprimirSubtotal Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function CerrarComprobante Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ImprimirCierreX Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ImprimirCierreZ Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function CargarLogo Lib "EpsonFiscalInterface.dll" (ByVal path As String) As Integer
    Private Declare Function EliminarLogo Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function EnviarComando Lib "EpsonFiscalInterface.dll" (ByVal comando As String) As Integer
    Private Declare Function ObtenerRespuesta Lib "EpsonFiscalInterface.dll" (ByVal buffer_salida As IntPtr, ByVal largo_buffer_salida As Integer, ByRef largo_final_buffer_salida As Integer) As Integer
    Private Declare Function ObtenerCodigoRetorno Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ObtenerEstadoFiscal Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ObtenerEstadoImpresora Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ObtenerCantidadCamposRespuestaExtendida Lib "EpsonFiscalInterface.dll" () As Integer
    Private Declare Function ObtenerRespuestaExtendida Lib "EpsonFiscalInterface.dll" (ByVal numero_campo As Integer, ByVal buffer_salida As IntPtr, ByVal largo_buffer_salida As Integer, ByRef largo_final_buffer_salida As Integer) As Integer

    ' -----------------------------------------------------------------------------
    ' GLOBAL DEFINES AREA
    ' -----------------------------------------------------------------------------
    Const ERROR_NINGUNO = 0

    Const ID_TIPO_COMPROBANTE_TIQUET = 1                            ' "83"  Tique
    Const ID_TIPO_COMPROBANTE_TIQUE_FACTURA = 2                     ' "81"  Tique Factura A, "82" Tique Factura B, "111" Tique Factura C, "118" Tique Factura M
    Const ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_CREDITO = 3             ' "110" Tique Nota de Credito, "112" Tique Nota de Credito A, "113" Tique Nota de Credito B, "114" Tique Nota de Credito C, "119" Tique Nota de Credito M
    Const ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_DEBITO = 4              ' "115" Tique Nota de Debito A, "116" Tique Nota de Debito B, "117" Tique Nota de Debito C, "120" Tique Nota de Debito M
    Const ID_TIPO_COMPROBANTE_DNFH_GENERIC = 21                     ' "910" DNFH Documento Generico 
    Const ID_TIPO_COMPROBANTE_DNFH_INTERNAL_USE = 22                ' "950" DNFH Documento de uso interno 
    Const ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_REMITO_R = 51         ' "91"  DNFH Valorizado Remito R 
    Const ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_REMITO_X = 52         ' "901" DNFH Valorizado Remito X 
    Const ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_RECIBO_X = 53         ' "902" DNFH Valorizado Recibo X 
    Const ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_PRESUPUESTO_X = 54    ' "903" DNFH Valorizado Presupuesto X 
    Const ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_DONACION = 55         ' "907" DNFH Valorizado Comprobante Donacion 

    Const ID_TIPO_DOCUMENTO_NINGUNO = 0
    Const ID_TIPO_DOCUMENTO_DNI = 1
    Const ID_TIPO_DOCUMENTO_CUIL = 2
    Const ID_TIPO_DOCUMENTO_CUIT = 3
    Const ID_TIPO_DOCUMENTO_CEDULA_IDENTIDAD = 4
    Const ID_TIPO_DOCUMENTO_PASAPORTE = 5
    Const ID_TIPO_DOCUMENTO_LIB_CIVICA = 6
    Const ID_TIPO_DOCUMENTO_LIB_ENROLAMIENTO = 7

    Const ID_RESPONSABILIDAD_IVA_NINGUNO = 0
    Const ID_RESPONSABILIDAD_IVA_RESPONSABLE_INSCRIPTO = 1
    Const ID_RESPONSABILIDAD_IVA_NO_RESPONSABLE = 3
    Const ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA = 4
    Const ID_RESPONSABILIDAD_IVA_CONSUMIDOR_FINAL = 5
    Const ID_RESPONSABILIDAD_IVA_EXENTO = 6
    Const ID_RESPONSABILIDAD_IVA_NO_CATEGORIZADO = 7
    Const ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA_SOCIAL = 8
    Const ID_RESPONSABILIDAD_IVA_CONTRIBUYENTE_EVENTUAL = 9
    Const ID_RESPONSABILIDAD_IVA_CONTRIBUYENTE_EVENTUAL_SOCIAL = 10
    Const ID_RESPONSABILIDAD_IVA_MONOTRIBUTO_INDEPENDIENTE_PROMOVIDO = 11

    Const ID_MODIFICADOR_AGREGAR_ITEM = 200
    Const ID_MODIFICADOR_ANULAR_ITEM = 201
    Const ID_MODIFICADOR_AGREGAR_ITEM_RETORNO_ENVASES = 202
    Const ID_MODIFICADOR_ANULAR_ITEM_RETORNO_ENVASES = 203
    Const ID_MODIFICADOR_AGREGAR_ITEM_BONIFICACION = 204
    Const ID_MODIFICADOR_ANULAR_ITEM_BONIFICACION = 205
    Const ID_MODIFICADOR_AGREGAR_ITEM_DESCUENTO = 206
    Const ID_MODIFICADOR_ANULAR_ITEM_DESCUENTO = 207
    Const ID_MODIFICADOR_AGREGAR_ITEM_ANTICIPO = 208
    Const ID_MODIFICADOR_ANULAR_ITEM_ANTICIPO = 209
    Const ID_MODIFICADOR_AGREGAR_ITEM_DESCUENTO_ANTICIPO = 210
    Const ID_MODIFICADOR_ANULAR_ITEM_DESCUENTO_ANTICIPO = 211
    Const ID_MODIFICADOR_DESCUENTO = 400
    Const ID_MODIFICADOR_AJUSTE = 401
    Const ID_MODIFICADOR_AJUSTE_NEGATIVO = 402
    Const ID_MODIFICADOR_AUDITORIA_DETALLADA = 500
    Const ID_MODIFICADOR_AUDITORIA_RESUMIDA = 501

    Const ID_MODIFICADOR_AGREGAR = ID_MODIFICADOR_AGREGAR_ITEM
    Const ID_MODIFICADOR_ANULAR = ID_MODIFICADOR_ANULAR_ITEM

    Const ID_TASA_IVA_NINGUNO = 0
    Const ID_TASA_IVA_EXENTO = 1
    Const ID_TASA_IVA_10_50 = 4
    Const ID_TASA_IVA_21_00 = 5

    Const ID_IMPUESTO_NINGUNO = 0
    Const ID_IMPUESTO_INTERNO_FIJO = 1
    Const ID_IMPUESTO_INTERNO_PORCENTUAL = 2

    Const ID_CODIGO_INTERNO = 1
    Const ID_CODIGO_MATRIX = 2

    Const AFIP_CODIGO_UNIDAD_MEDIDA_SIN_DESCRIPCION = 0
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO = 1
    Const AFIP_CODIGO_UNIDAD_MEDIDA_METROS = 2
    Const AFIP_CODIGO_UNIDAD_MEDIDA_METRO_CUADRADO = 3
    Const AFIP_CODIGO_UNIDAD_MEDIDA_METRO_CUBICO = 4
    Const AFIP_CODIGO_UNIDAD_MEDIDA_LITROS = 5
    Const AFIP_CODIGO_UNIDAD_MEDIDA_UNIDAD = 7
    Const AFIP_CODIGO_UNIDAD_MEDIDA_PAR = 8
    Const AFIP_CODIGO_UNIDAD_MEDIDA_DOCENA = 9
    Const AFIP_CODIGO_UNIDAD_MEDIDA_QUILATE = 10
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILLAR = 11
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MEGA_U_INTER_ACT_ANTIB = 12
    Const AFIP_CODIGO_UNIDAD_MEDIDA_UNIDAD_INT_ACT_INMUNG = 13
    Const AFIP_CODIGO_UNIDAD_MEDIDA_GRAMO = 14
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILIMETRO = 15
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILIMETRO_CUBICO = 16
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOMETRO = 17
    Const AFIP_CODIGO_UNIDAD_MEDIDA_HECTOLITRO = 18
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MEGA_UNIDAD_INT_ACT_INMUNG = 19
    Const AFIP_CODIGO_UNIDAD_MEDIDA_CENTIMETRO = 20
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO_ACTIVO = 21
    Const AFIP_CODIGO_UNIDAD_MEDIDA_GRAMO_ACTIVO = 22
    Const AFIP_CODIGO_UNIDAD_MEDIDA_GRAMO_BASE = 23
    Const AFIP_CODIGO_UNIDAD_MEDIDA_UIACTHOR = 24
    Const AFIP_CODIGO_UNIDAD_MEDIDA_JGO_PQT_MAZO_NAIPES = 25
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MUIACTHOR = 26
    Const AFIP_CODIGO_UNIDAD_MEDIDA_CENTIMETRO_CUBICO = 27
    Const AFIP_CODIGO_UNIDAD_MEDIDA_UIACTANT = 28
    Const AFIP_CODIGO_UNIDAD_MEDIDA_TONELADA = 29
    Const AFIP_CODIGO_UNIDAD_MEDIDA_DECAMETRO_CUBICO = 30
    Const AFIP_CODIGO_UNIDAD_MEDIDA_HECTOMETRO_CUBICO = 31
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOMETRO_CUBICO = 32
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MICROGRAMO = 33
    Const AFIP_CODIGO_UNIDAD_MEDIDA_NANOGRAMO = 34
    Const AFIP_CODIGO_UNIDAD_MEDIDA_PICOGRAMO = 35
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MUIACTANT = 36
    Const AFIP_CODIGO_UNIDAD_MEDIDA_UIACTIG = 37
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILIGRAMO = 41
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILILITRO = 47
    Const AFIP_CODIGO_UNIDAD_MEDIDA_CURIE = 48
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MILICURIE = 49
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MICROCURIE = 50
    Const AFIP_CODIGO_UNIDAD_MEDIDA_U_INTER_ACT_HORMONAL = 51
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MEGA_U_INTER_ACT_HORMONAL = 52
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO_BASE = 53
    Const AFIP_CODIGO_UNIDAD_MEDIDA_GRUESA = 54
    Const AFIP_CODIGO_UNIDAD_MEDIDA_MUIACTIG = 55
    Const AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO_BRUTO = 61
    Const AFIP_CODIGO_UNIDAD_MEDIDA_PACK = 62
    Const AFIP_CODIGO_UNIDAD_MEDIDA_HORMA = 63

    Const AFIP_CODIGO_OTROS_TRIBUTOS_IMPUESTOS_NACIONALES = 1
    Const AFIP_CODIGO_OTROS_TRIBUTOS_IMPUESTOS_PROVINCIAL = 2
    Const AFIP_CODIGO_OTROS_TRIBUTOS_IMPUESTO_MUNICIPAL = 3
    Const AFIP_CODIGO_OTROS_TRIBUTOS_IMPUESTO_INTERNOS = 4
    Const AFIP_CODIGO_OTROS_TRIBUTOS_INGRESOS_BRUTOS = 5
    Const AFIP_CODIGO_OTROS_TRIBUTOS_PERCEPCION_DE_IVA = 6
    Const AFIP_CODIGO_OTROS_TRIBUTOS_PERCEPCION_DE_INGRESOS_BRUTOS = 7
    Const AFIP_CODIGO_OTROS_TRIBUTOS_PERCEPCION_POR_IMPUESTOS_MUNICIPALES = 8
    Const AFIP_CODIGO_OTROS_TRIBUTOS_OTRAS_PERCEPCIONES = 9
    Const AFIP_CODIGO_OTROS_TRIBUTOS_OTROS = 99

    Const AFIP_CODIGO_FORMA_DE_PAGO_CARTA_DE_CREDITO_DOCUMENTARIO = 1
    Const AFIP_CODIGO_FORMA_DE_PAGO_CARTAS_DE_CREDITO_SIMPLE = 2
    Const AFIP_CODIGO_FORMA_DE_PAGO_CHEQUE = 3
    Const AFIP_CODIGO_FORMA_DE_PAGO_CHEQUES_CANCELATORIOS = 4
    Const AFIP_CODIGO_FORMA_DE_PAGO_CREDITO_DOCUMENTARIO = 5
    Const AFIP_CODIGO_FORMA_DE_PAGO_CUENTA_CORRIENTE = 6
    Const AFIP_CODIGO_FORMA_DE_PAGO_DEPOSITO = 7
    Const AFIP_CODIGO_FORMA_DE_PAGO_EFECTIVO = 8
    Const AFIP_CODIGO_FORMA_DE_PAGO_ENDOSO_DE_CHEQUE = 9
    Const AFIP_CODIGO_FORMA_DE_PAGO_FACTURA_DE_CREDITO = 10
    Const AFIP_CODIGO_FORMA_DE_PAGO_GARANTIAS_BANCARIAS = 11
    Const AFIP_CODIGO_FORMA_DE_PAGO_GIROS = 12
    Const AFIP_CODIGO_FORMA_DE_PAGO_LETRAS_DE_CAMBIO = 13
    Const AFIP_CODIGO_FORMA_DE_PAGO_MEDIOS_DE_PAGO_DE_COMERCIO_EXTERIOR = 14
    Const AFIP_CODIGO_FORMA_DE_PAGO_ORDEN_DE_PAGO_DOCUMENTARIA = 15
    Const AFIP_CODIGO_FORMA_DE_PAGO_ORDEN_DE_PAGO_SIMPLE = 16
    Const AFIP_CODIGO_FORMA_DE_PAGO_PAGO_CONTRA_REEMBOLSO = 17
    Const AFIP_CODIGO_FORMA_DE_PAGO_REMESA_DOCUMENTARIA = 18
    Const AFIP_CODIGO_FORMA_DE_PAGO_REMESA_SIMPLE = 19
    Const AFIP_CODIGO_FORMA_DE_PAGO_TARJETA_DE_CREDITO = 20
    Const AFIP_CODIGO_FORMA_DE_PAGO_TARJETA_DE_DEBITO = 21
    Const AFIP_CODIGO_FORMA_DE_PAGO_TICKET = 22
    Const AFIP_CODIGO_FORMA_DE_PAGO_TRANSFERENCIA_BANCARIA = 23
    Const AFIP_CODIGO_FORMA_DE_PAGO_TRANSFERENCIA_NO_BANCARIA = 24
    Const AFIP_CODIGO_FORMA_DE_PAGO_OTROS_MEDIOS = 99

    Const DOC_EN_PROGRESO = 1003
    Const SUBESTADOS = 1006
    Const JORNADA_FISCAL = 1007
    Const ESTADO_MEM_TRANSACCIONES = 1009
    Const ESTADO_MEM_FISCAL = 1011
    Const MODO_TECNICO = 1012
    Const ESTADO_CERTIFICADOS_DIGITALES = 1013
    Const MODO_FUNCIONAMIENTO_EQUIPO = 1015
    Const ESTADO_ESTACION_RECIBOS = 7001
    Const ESTADO_ESTACION_JOURNAL = 7003
    Const ESTADO_ESTACION_SLIP_SENSOR_VALIDACION = 7004
    Const ESTADO_ESTACION_SLIP_SENSOR_TOF = 7005
    Const ESTADO_ESTACION_SLIP_SENSOR_BOF = 7006
    Const ESTADO_ESTACION_SLIP_VALIDACION_SENSOR_ESPERA = 7008
    Const ESTADO_ESTACION_SELECCIONADA = 7010
    Const ESTADO_CAJON_DINERO = 7012
    Const ESTADO_TAPA = 7013
    Const IMPRESORA_CON_ERROR = 7014
    Const IMPRESORA_EN_LINEA = 7015
    Const ESTADO_CONEXION = 9003

    Const MAX_ANSWER = 200
    Const MAX_DESCRIPTION = 500
    Const MAX_COMMAND = 1000
    Dim retorno As Integer = 0

    Dim AlmacenarLogoFiscalNombre As String = "logo\\logo_chico_horizontal_completo.png"
    Dim AlmacenarLogoFiscalThread As Thread
    Dim AlmacenarLogoFiscalThreadStart As New ThreadStart(AddressOf AlmacenarLogoFiscalThreadSegundoPlano)
    Dim AlmacenarLogoFiscalDeleteChangeGUI As New MethodInvoker(AddressOf AlmacenarLogoFiscalActualizarGUI)


    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cmbPort.SelectedIndex = 0
        cmbBaudRate.SelectedIndex = 0
        btnDisconnect.Enabled = False
        labelVersion.Text = EXAMPLE_VERSION
        Call DeshabilitarPaneles()
        Call ReiniciarBarraDeEstado()
    End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        Call ConectarFiscal()
    End Sub

    Private Sub btnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisconnect.Click
        Call DesconectarFiscal()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnX.Click
        Call ImprimirX()
    End Sub

    Private Sub btnZ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnZ.Click
        Call ImprimirZ()
    End Sub

    Private Sub btnDllVersion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDllVersion.Click
        ' ejecutar funcion
        Dim version_dll As String
        version_dll = ObtenerVersionDll()

        ' efecto visual
        Call AgregarVersionDllEnToolbar(version_dll)
    End Sub

    Private Sub btnVersion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFPVersion.Click
        Call ObtenerVersionFiscal()
    End Sub

    Private Sub btnReceiptNro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetFiscalizationData.Click
        Call ObtenerDatosFIscalizacion()
    End Sub

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        Call AbrirDocumentoFiscal()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call CancelarVenta()
    End Sub

    Private Sub btnDateTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDateTime.Click
        Call ObtenerFechaHora()
    End Sub

    Private Sub btnItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnItemUp.Click
        Call ItemVenta()
    End Sub

    Private Sub btnPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPayment.Click
        Call PagarTdC()
    End Sub

    Private Sub btnSubtotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubtotal.Click
        Call ObtenerSubtotal()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Dim nroComp As String

        ' previamente obtenemos el numero de comprobante para mostarlo en el log
        nroComp = ObtenerNroComprobanteEnCurso()

        ' ejcutar funcion
        retorno = CerrarCualquierDocumentoEnCurso()
        MostrarMensaje(retorno, "Comprobante totalizado nro.: " & nroComp)
    End Sub

    Private Sub btnItemDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnItemDown.Click
        Call Bonificar()
    End Sub

    Private Sub btnExtraDescription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExtraDescription.Click
        Call AlmacenarDescripcionExtra()
    End Sub

    Private Sub btnAudit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAudit.Click
        If rdbtnByClosureZ.Checked = True Then
            ' por cierre Z
            Call AuditoriaResumidaXRangoZ()
        Else
            ' por fecha
            Call AuditoriaResumidaXRangoZPorFecha()
        End If
    End Sub

    Private Sub btnDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownload.Click
        If rdbtnByClosureZ.Checked = True Then
            ' por cierre Z
            Call DescargarXRangoZ()
        Else
            ' por fecha
            Call DescargarXRangoZPorFecha()
        End If

        ' mostrar directorio donde estan las descargas
        If retorno = ERROR_NINGUNO Then
            System.Diagnostics.Process.Start("c:\\descargas")
        End If
    End Sub

    Private Sub btnFeedPaper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFeedPaper.Click
        Call AvanzarPapel(InputBox("Cantidad de líneas a avanzar: ", "", "1", ))
    End Sub

    Private Sub btnCutPaper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCutPaper.Click
        Call CortarPapel()
    End Sub

    Private Sub btnOpenCashDrawer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call AbrirCajon1()
    End Sub

    Private Sub btnDocInProgress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDocInProgress.Click
        Call ConsultarTipoComprobante()
    End Sub

    Private Sub btnFiscalDay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFiscalDay.Click
        Call ObtenerEstadoJornada()
    End Sub

    Private Sub btnCover_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOperatingMode.Click
        Call ObtenerModoFuncionamiento()
    End Sub

    Private Sub btnCargarLogo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadLogo.Click
        Call AlmacenarLogoFiscal()
    End Sub

    Private Sub MostrarMensaje(ByVal retorno, ByVal mensaje)
        Dim respuesta As StringBuilder = New StringBuilder(MAX_DESCRIPTION)
        Dim hexVal As String

        If retorno = ERROR_NINGUNO Then
            ' antiguo mensaje:   MsgBox(mensaje, MsgBoxStyle.Information, "Información")
            MsgLogAgregar(mensaje, MsgBoxStyle.Information, "Información")
        Else
            ConsultarDescripcionDeError(retorno, respuesta, MAX_DESCRIPTION)
            hexVal = String.Format("{0:X4}", retorno)

            ' antiguo mensaje:   MsgBox("Error: " & hexVal & vbCrLf & "Descripción: " & respuesta.ToString, MsgBoxStyle.Exclamation, "Error!")
            MsgLogAgregar("Error: 0x" & hexVal & vbCrLf & "Descripción: " & respuesta.ToString, MsgBoxStyle.Exclamation, "Error!")
        End If
    End Sub

    Private Sub MsgLogAgregar(ByVal mensaje As String, ByVal tipo As MsgBoxStyle, ByVal titulo As String)
        Dim default_color As System.Drawing.Color
        Dim information_color As System.Drawing.Color
        Dim error_color As System.Drawing.Color

        ' init 
        default_color = ctrlRichTextBoxLog.SelectionColor
        information_color = Color.Blue
        error_color = Color.Red

        ' beep 
        If tipo <> MsgBoxStyle.Information Then
            Beep()
        End If

        ' ir al final del texto
        ctrlRichTextBoxLog.SelectionStart = ctrlRichTextBoxLog.Text.Length
        ctrlRichTextBoxLog.SelectionLength = 0
        ctrlRichTextBoxLog.Focus()

        ' titulo del mensaje
        If tipo = MsgBoxStyle.Information Then
            ctrlRichTextBoxLog.SelectionColor = information_color
        Else
            ctrlRichTextBoxLog.SelectionColor = error_color
        End If
        ctrlRichTextBoxLog.AppendText(titulo)

        ' cuerpo del mensaje 
        ctrlRichTextBoxLog.SelectionColor = default_color
        ctrlRichTextBoxLog.AppendText(vbCrLf)
        ctrlRichTextBoxLog.AppendText(mensaje)
        ctrlRichTextBoxLog.AppendText(vbCrLf)
        ctrlRichTextBoxLog.AppendText(vbCrLf)

        ' ir al final del texto
        ctrlRichTextBoxLog.SelectionStart = ctrlRichTextBoxLog.Text.Length
        ctrlRichTextBoxLog.SelectionLength = 0
        ctrlRichTextBoxLog.Focus()
    End Sub

    Private Sub ConectarFiscal()
        ' habilitar log de comunicacion
        DetenerLog()   ' just in case 
        If chckEnable.Checked Then
            ComenzarLog(True)
            ' Cuando se invoca esta función se borra el previo archivo de log existente.
            ' el archivo de LOG tendrá el mismo nombre que el ejecutable con la extensión
            ' .log y también encontrará en el mismo directorio que el ejecutable
        End If

        ' conectar
        ConfigurarPuerto(cmbPort.SelectedItem.ToString)
        ConfigurarVelocidad(CInt(cmbBaudRate.SelectedItem))
        retorno = Conectar()
        If retorno <> 0 Then
            MostrarMensaje(retorno, "")
            Exit Sub
        End If

        btnDisconnect.Enabled = True
        btnConnect.Enabled = False
        Select Case cmbPort.SelectedIndex
            Case 0
                ToolStripStatusLabel2.Text = "     USB     "
            Case 1
                ToolStripStatusLabel2.Text = "     COM1     "
            Case 2
                ToolStripStatusLabel2.Text = "     COM2     "
            Case 3
                ToolStripStatusLabel2.Text = "     COM3     "
            Case 4
                ToolStripStatusLabel2.Text = "     COM4     "
            Case 5
                ToolStripStatusLabel2.Text = "     COM5     "
            Case 6
                ToolStripStatusLabel2.Text = "     COM6     "
            Case 7
                ToolStripStatusLabel2.Text = "     COM7     "
            Case 8
                ToolStripStatusLabel2.Text = "     COM8     "
            Case 9
                ToolStripStatusLabel2.Text = "     COM9     "
            Case 10
                ToolStripStatusLabel2.Text = "     COM10     "
        End Select

        If cmbPort.SelectedIndex <> 0 Then
            Select Case cmbBaudRate.SelectedIndex
                Case 0
                    ToolStripStatusLabel3.Text = "     9600     "
                Case 1
                    ToolStripStatusLabel3.Text = "     19200     "
                Case 2
                    ToolStripStatusLabel3.Text = "     38400     "
                Case 3
                    ToolStripStatusLabel3.Text = "     57600     "
                Case 4
                    ToolStripStatusLabel3.Text = "     115200     "
            End Select
        End If
        Call HabilitarPaneles()
        MostrarMensaje(retorno, "Host vinculado a la impresora fiscal.")
    End Sub

    Private Sub DesconectarFiscal()
        retorno = Desconectar()
        If retorno = 0 Then
            DetenerLog()
            Call DeshabilitarPaneles()
            Call ReiniciarBarraDeEstado()
            btnDisconnect.Enabled = False
            btnConnect.Enabled = True
            MostrarMensaje(retorno, "Host desconectado de la impresora fiscal.")
        Else
            MostrarMensaje(retorno, "")
        End If
    End Sub

    Private Sub HabilitarPaneles()
        GroupBox2.Enabled = True
        GroupBox3.Enabled = True
        GroupBox4.Enabled = True
        GroupBox5.Enabled = True
        GroupBox6.Enabled = True
        ' GroupBox7.Enabled = True    'Panel Log siempre habilitado
        GroupBox8.Enabled = True
        GroupBox9.Enabled = True
        GroupBox11.Enabled = True

        _GroupBox12_Enabled() 'Al reves de los otros


    End Sub

    Private Sub DeshabilitarPaneles()
        GroupBox2.Enabled = False
        GroupBox3.Enabled = False
        GroupBox4.Enabled = False
        GroupBox5.Enabled = False
        GroupBox6.Enabled = False
        'GroupBox7.Enabled = False    'Panel Log siempre habilitado
        GroupBox8.Enabled = False
        GroupBox9.Enabled = False
        GroupBox11.Enabled = False

        _GroupBox12_Disable() 'Al reves de los otros

    End Sub

    Sub _GroupBox12_Enabled()
        GroupBox12.Enabled = True
        chckEnable.Enabled = False
        btnShowLog.Enabled = True
    End Sub

    Sub _GroupBox12_Disable()
        GroupBox12.Enabled = True
        chckEnable.Enabled = True
        btnShowLog.Enabled = True
    End Sub

    Private Sub ImprimirZ()
        retorno = ImprimirCierreZ()
        MostrarMensaje(retorno, "Jornada cerrada.")
    End Sub

    Private Sub ImprimirX()
        retorno = ImprimirCierreX()
        MostrarMensaje(retorno, "Cambio de cajero.")
    End Sub

    Private Function ConvertirEnMonto(ByVal valor As String) As String
        Dim tmp As String = ""
        Dim pos As Integer = -1

        ' buscar string punto (".") dentro del string valor
        pos = InStr(valor, ".")
        If pos <= 0 Then
            tmp = "." & valor
        Else
            tmp = valor
        End If

        ' convertir a valor monto

        tmp = String.Format("{0:C2}", tmp)

        ' punto de salida
        ConvertirEnMonto = tmp
    End Function

    Private Sub _ObtenerRespuestaDeComandoGenerico()
        Dim id_error As Integer = 0
        Dim respuesta As String = ""
        Dim FIELD_OUTPUT_MAX_LEN As Integer = (65536 * 1)

        ' READ
        ' crear un buffer en memoria con el tamaño de bytes que indice la constante FIELD_OUTPUT_MAX_LEN (típico MALLOC)
        Dim puntero_buffer_salida As IntPtr = Runtime.InteropServices.Marshal.AllocHGlobal(FIELD_OUTPUT_MAX_LEN)

        ' crear variable del tipo integer donde devolverá la cantidad de bytes utilizados del buffer creado
        Dim respuesta_final_buffer_salida As Integer = 0

        ' llamar a la funcion
        id_error = ObtenerRespuesta(puntero_buffer_salida, FIELD_OUTPUT_MAX_LEN, respuesta_final_buffer_salida)

        ' copiar la respuesta contenida segun el puntero "puntero_buffer_salida" a la variable "respuesta"
        respuesta = Runtime.InteropServices.Marshal.PtrToStringAnsi(puntero_buffer_salida, respuesta_final_buffer_salida)

        ' liberar la memoria solicitada (típico FREE)
        Runtime.InteropServices.Marshal.FreeHGlobal(puntero_buffer_salida)

        ' mostrar la respuesta
        MostrarMensaje(id_error, "ObtenerRespuesta(...): " & respuesta)

    End Sub


    Private Sub EnviarComandoGenerico_ObtenerInfoJornadaParaTicket()
        Dim mensaje As String = ""
        Dim value As Integer = 0
        Dim tmp As String = ""

        ' SEND COMMAND FRAME
        ' consultar info
        retorno = EnviarComando("080A|0000|83")
        MostrarMensaje(retorno, "EnviarComando(""080A|0000|83"")")

        ' GET ANSWER FRAME
        ' consultar respuesta
        _ObtenerRespuestaDeComandoGenerico()

        ' QUERY
        ' Consultar el codigo de retorno
        value = ObtenerCodigoRetorno()
        tmp = String.Format("{0:X4}", value)
        mensaje = "Código de retorno:          0x" & tmp

        ' Consultar el estado fiscal
        value = ObtenerEstadoFiscal()
        tmp = String.Format("{0:X4}", value)
        mensaje = mensaje & vbCrLf & "Estado fiscal:              0x" & tmp

        ' Consultar el estado de la impresora
        value = ObtenerEstadoImpresora()
        tmp = String.Format("{0:X4}", value)
        mensaje = mensaje & vbCrLf & "Estado de impresora:        0x" & tmp

        ' Consultar cantidad de campos de salida
        value = ObtenerCantidadCamposRespuestaExtendida()
        mensaje = mensaje & vbCrLf & "Cantidad de campos de salida: " & value.ToString()

        ' READ
        If retorno = ERROR_NINGUNO Then
            Dim fecha_apertura_jornada As String = ""
            retorno = ObtenerCampoSalida_TipoString(1, fecha_apertura_jornada)
            If retorno = ERROR_NINGUNO Then
                mensaje = mensaje & vbCrLf & "Fecha de apertura de la jornada fiscal: " + fecha_apertura_jornada
            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If
        End If

        If retorno = ERROR_NINGUNO Then
            Dim total As String = ""
            retorno = ObtenerCampoSalida_TipoString(9, total)
            If retorno = ERROR_NINGUNO Then
                mensaje = mensaje & vbCrLf & "Total de ventas: " + total
            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If
        End If

        ' mostrar en el log la información obtenida
        MostrarMensaje(retorno, mensaje)
    End Sub

    Private Sub EnviarComandoGenerico_Imprimir_tique_tecnico()
        Dim mensaje As String = ""
        Dim value As Integer = 0
        Dim tmp As String = ""

        ' SEND
        ' Enviar un comando generico: en este caso un tique técnico
        retorno = EnviarComando("0210|0000")
        MostrarMensaje(retorno, "EnviarComando(""0210|0000"")")

        ' GET ANSWER FRAME
        ' consultar respuesta
        _ObtenerRespuestaDeComandoGenerico()

        ' QUERY
        ' Consultar el codigo de retorno
        value = ObtenerCodigoRetorno()
        tmp = String.Format("{0:X4}", value)
        mensaje = "Código de retorno:          0x" & tmp

        ' Consultar el estado fiscal
        value = ObtenerEstadoFiscal()
        tmp = String.Format("{0:X4}", value)
        mensaje = mensaje & vbCrLf & "Estado fiscal:              0x" & tmp

        ' Consultar el estado de la impresora
        value = ObtenerEstadoImpresora()
        tmp = String.Format("{0:X4}", value)
        mensaje = mensaje & vbCrLf & "Estado de impresora:        0x" & tmp

        ' Consultar cantidad de campos de salida
        value = ObtenerCantidadCamposRespuestaExtendida()
        mensaje = mensaje & vbCrLf & "Cantidad de campos de salida: " & value.ToString()

        ' READ
        If retorno = ERROR_NINGUNO Then
            '  Obtener la respuesta del campo de salida número 1:
            Dim numero_comprobante As String
            numero_comprobante = ""
            retorno = ObtenerCampoSalida_TipoString(1, numero_comprobante)
            If retorno = ERROR_NINGUNO Then
                mensaje = mensaje & vbCrLf & "Número de Tique Fiscal: " & numero_comprobante
            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If

            '  Obtener la respuesta del campo de salida número 2:
            Dim monto_total As String
            monto_total = ""
            retorno = ObtenerCampoSalida_TipoString(2, monto_total)
            If retorno = ERROR_NINGUNO Then
                'monto_total = "." & monto_total
                mensaje = mensaje & vbCrLf & "Monto Total: " & ConvertirEnMonto(monto_total)

            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If

            '  Obtener la respuesta del campo de salida número 3:
            Dim monto_iva As String
            monto_iva = ""
            retorno = ObtenerCampoSalida_TipoString(3, monto_iva)
            If retorno = ERROR_NINGUNO Then
                mensaje = mensaje & vbCrLf & "Total IVA: " & ConvertirEnMonto(monto_iva)
            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If

            '  Obtener la respuesta del campo de salida número 4:
            Dim vuelto As String
            vuelto = ""
            retorno = ObtenerCampoSalida_TipoString(3, vuelto)
            If retorno = ERROR_NINGUNO Then
                mensaje = mensaje & vbCrLf & "Vuelto: " & ConvertirEnMonto(vuelto)
            Else
                MostrarMensaje(retorno, "")
                Exit Sub
            End If

            ' mostrar en el log la información obtenida
            MostrarMensaje(retorno, mensaje)
        End If
    End Sub

    Private Sub EnviarComandoGenerico_ImprimirX_con_preferencias_particulares()
        ' SEND
        ' Enviar un comando generico: en este caso un Cierre X (cmd: 0802)
        '                             con preferencias particulares (extension: 0001)
        '                             los campos van separados por el signo PIPE  "|"
        retorno = EnviarComando("0802|0001")
        MostrarMensaje(retorno, "EnviarComando(""0802|0001"")")

        ' GET ANSWER FRAME
        ' consultar respuesta
        _ObtenerRespuestaDeComandoGenerico()

        ' READ
        If retorno = ERROR_NINGUNO Then
            '  Obtener la respuesta del campo de salida número 1:
            '                                                   como el comando enviado 0802, tiene un campo de salida
            '                                                   donde se informa el número del comprobante X emitido.
            '                                                   vamos a consultarlo de la siguiente forma:
            Dim numero_comprobante As String
            numero_comprobante = ""

            '  Importante, ya que la respuesta según el manual de especificaciones
            '  es del tipo texto. 
            '  Si fueran datos binarios, puede utilizar la funcion: ObtenerCampoSalida_TipoBuffer
            retorno = ObtenerCampoSalida_TipoString(1, numero_comprobante)

            '  Mostrar resultados
            MostrarMensaje(retorno, "El Número de comprobante del cambio de cajero es: " + numero_comprobante)
        End If
    End Sub

    Private Function ObtenerCampoSalida_TipoString(ByVal numero_campo_salida As Integer, ByRef respuesta As String) As Integer
        Const FIELD_OUTPUT_MAX_LEN As Integer = 65536

        ' READ
        ' crear un buffer en memoria con el tamaño de bytes que indice la constante FIELD_OUTPUT_MAX_LEN (típico MALLOC)
        Dim puntero_buffer_salida As IntPtr = Runtime.InteropServices.Marshal.AllocHGlobal(FIELD_OUTPUT_MAX_LEN)

        ' crear variable del tipo integer donde devolverá la cantidad de bytes utilizados del buffer creado
        Dim respuesta_final_buffer_salida As Integer

        ' llamar a la funcion
        retorno = ObtenerRespuestaExtendida(numero_campo_salida, puntero_buffer_salida, FIELD_OUTPUT_MAX_LEN, respuesta_final_buffer_salida)

        ' copiar la respuesta contenida segun el puntero "puntero_buffer_salida" a la variable "respuesta"
        respuesta = Runtime.InteropServices.Marshal.PtrToStringAnsi(puntero_buffer_salida, respuesta_final_buffer_salida)

        ' Ejemplo para una estrucura de datos, ver el link: 
        ' https://stackoverflow.com/questions/16481622/passing-parameter-from-vb-net-to-c-structure

        ' liberar la memoria solicitada (típico FREE)
        Runtime.InteropServices.Marshal.FreeHGlobal(puntero_buffer_salida)

        ' retorno del error
        ObtenerCampoSalida_TipoString = retorno
    End Function

    Private Function ObtenerCampoSalida_TipoBuffer(ByVal numero_campo_salida As Integer, ByRef respuesta() As Byte) As Integer
        Const FIELD_OUTPUT_MAX_LEN As Integer = 65536

        ' READ
        ' crear un buffer en memoria con el tamaño de bytes que indice la constante FIELD_OUTPUT_MAX_LEN (típico MALLOC)
        Dim puntero_buffer_salida As IntPtr = Runtime.InteropServices.Marshal.AllocHGlobal(FIELD_OUTPUT_MAX_LEN)

        ' crear variable del tipo integer donde devolverá la cantidad de bytes utilizados del buffer creado
        Dim respuesta_final_buffer_salida As Integer

        ' llamar a la funcion
        retorno = ObtenerRespuestaExtendida(numero_campo_salida, puntero_buffer_salida, FIELD_OUTPUT_MAX_LEN, respuesta_final_buffer_salida)

        ' copiar la respuesta contenida segun el puntero "puntero_buffer_salida" a la variable del tipo arreglo "respuesta" (un buffer)
        Runtime.InteropServices.Marshal.Copy(puntero_buffer_salida, respuesta, 0, respuesta_final_buffer_salida)

        ' Ejemplo para una estrucura de datos, ver el link: 
        ' https://stackoverflow.com/questions/16481622/passing-parameter-from-vb-net-to-c-structure

        ' liberar la memoria solicitada (típico FREE)
        Runtime.InteropServices.Marshal.FreeHGlobal(puntero_buffer_salida)

        ' retorno del error
        ObtenerCampoSalida_TipoBuffer = retorno

    End Function

    Private Sub EnviarComandoGenerico_get_fiscal_status()
        Dim mensaje As String = ""
        Dim value As Integer = 0
        Dim tmp As String = ""

        ' QUERY
        value = ObtenerEstadoFiscal()
        tmp = String.Format("{0:X4}", value)
        mensaje = "Estado fiscal: 0x" & tmp
        MostrarMensaje(0, mensaje)
    End Sub

    Private Sub EnviarComandoGenerico_get_printer_status()
        Dim mensaje As String = ""
        Dim value As Integer = 0
        Dim tmp As String = ""

        ' QUERY
        value = ObtenerEstadoImpresora()
        tmp = String.Format("{0:X4}", value)
        mensaje = "Estado de impresora: 0x" & tmp
        MostrarMensaje(0, mensaje)
    End Sub

    Private Sub EnviarComandoGenerico_get_return_code()
        Dim mensaje As String = ""
        Dim value As Integer = 0
        Dim tmp As String = ""

        ' QUERY
        value = ObtenerCodigoRetorno()
        tmp = String.Format("{0:X4}", value)
        mensaje = "Código de retorno: 0x" & tmp
        MostrarMensaje(0, mensaje)
    End Sub

    Private Sub EnviarComandoGenerico_get_qty_output_fields()
        Dim mensaje As String = ""
        Dim value As Integer = 0

        ' QUERY
        value = ObtenerCantidadCamposRespuestaExtendida()
        mensaje = "Cantidad de campos de salida: " & value.ToString()
        MostrarMensaje(0, mensaje)
    End Sub

    Private Function ObtenerVersionDll() As String
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim mayor As Integer
        Dim menor As Integer

        ' inicializar variable
        respuesta.Clear()

        ' ejecutar funcion
        retorno = ConsultarVersionDll(respuesta, MAX_ANSWER, mayor, menor)
        MostrarMensaje(retorno, "Versión de la dll --> " & respuesta.ToString)

        ' retornar string 
        ObtenerVersionDll = respuesta.ToString
    End Function

    Private Sub ObtenerVersionFiscal()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim mayor As Integer
        Dim menor As Integer

        retorno = ConsultarVersionEquipo(respuesta, MAX_ANSWER, mayor, menor)
        MostrarMensaje(retorno, "Versión de la impresora fiscal --> " & respuesta.ToString & " " & mayor.ToString("D2") & "." & menor.ToString("D2"))
    End Sub

    Private Sub ObtenerPuntoDeVenta()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarNumeroPuntoDeVenta(respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "Punto de Venta: " & respuesta.ToString)
    End Sub

    Private Sub ObtenerEstadoDeterminado()
        Dim id As Integer
        Dim id_str As String
        Dim respuesta As Integer
        Dim mensaje As String

        ' init
        mensaje = ""

        ' get id 
        id_str = cmbGetTypeStatus.Text.Substring(0, 4)
        id = Val(id_str)

        ' consultar
        retorno = ConsultarEstado(id, respuesta)

        ' salir por error
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Consultar tipo de estado ")
            Exit Sub
        End If


        ' mostrar respuesta
        Select Case id
            Case DOC_EN_PROGRESO
                Select Case respuesta
                    Case 0
                        mensaje = "Sin documentos en progreso"
                    Case 1
                        mensaje = "Tique/Tique-Nota de Crédito"
                    Case 2
                        mensaje = "Tique-Factura A/B/C/M"
                    Case 3
                        mensaje = "Tique-Nota de Crédito A/B/C/M"
                    Case 4
                        mensaje = "Tique-Nota de Débito A/B/C/M"
                    Case 6
                        mensaje = "Documento de Auditoría"
                    Case 8
                        mensaje = "DNFH Genérico/Uso Interno (rollo)"
                    Case 10
                        mensaje = "DNFH"
                End Select

            Case SUBESTADOS
                Select Case respuesta
                    Case 0
                        mensaje = "Sin subestados"
                    Case 1
                        mensaje = "Solicitud o carga de certificado digital"
                    Case 2
                        mensaje = "Configuración de Scanner"
                    Case 3
                        mensaje = "Configuración de Logo"
                    Case 4
                        mensaje = "Auditoría en progreso"
                    Case 5
                        mensaje = "Descarga de reporte en progreso"
                    Case 6
                        mensaje = "Reimpresión en progreso"
                    Case 7
                        mensaje = "Descarga de reporte de eventos en progreso"
                End Select

            Case JORNADA_FISCAL
                If respuesta = 0 Then
                    mensaje = "Jornada cerrada"
                Else
                    mensaje = "Jornada abierta"
                End If

            Case ESTADO_MEM_TRANSACCIONES
                Select Case respuesta
                    Case 0
                        mensaje = "Memoria de transacciones en perfecto estado"
                    Case 1
                        mensaje = "Memoria de transacciones cerca de su llenado"
                    Case 2
                        mensaje = "Memoria de transacciones llena"
                    Case 3
                        mensaje = "Memoria de transacciones con desperfectos"
                End Select

            Case ESTADO_MEM_FISCAL
                Select Case respuesta
                    Case 0
                        mensaje = "Memoria fiscal en perfecto estado"
                    Case 1
                        mensaje = "Memoria fiscal cerca de su llenado"
                    Case 2
                        mensaje = "Memoria fiscal llena"
                    Case 3
                        mensaje = "Memoria fiscal con desperfectos"
                End Select

            Case MODO_TECNICO
                Select Case respuesta
                    Case 0
                        mensaje = "Modo técnico inactivo"
                    Case 1
                        mensaje = "Modo técnico activo"
                End Select

            Case ESTADO_CERTIFICADOS_DIGITALES
                Select Case respuesta
                    Case 0
                        mensaje = "Certificados digitales válidos"
                    Case 1
                        mensaje = "certificados digitales vencido(s), cercano(s) de su expiración, inválido(s)"
                End Select

            Case MODO_FUNCIONAMIENTO_EQUIPO
                Select Case respuesta
                    Case 0
                        mensaje = "Modo bloqueado por software"
                    Case 1
                        mensaje = "Modo manufactura"
                    Case 2
                        mensaje = "Modo entrenamiento"
                    Case 3
                        mensaje = "Modo fiscal"
                    Case 15
                        mensaje = "Bloqueo por hardware"
                End Select

            Case ESTADO_ESTACION_RECIBOS
                Select Case respuesta
                    Case 0
                        mensaje = "Sin problemas"
                    Case 1
                        mensaje = "Poco papel disponible"
                    Case 2
                        mensaje = "Papel no disponible"
                End Select

            Case ESTADO_ESTACION_JOURNAL
                Select Case respuesta
                    Case 0
                        mensaje = "Sin problemas"
                    Case 1
                        mensaje = "Poco papel disponible"
                    Case 2
                        mensaje = "Papel no disponible"
                End Select

            Case ESTADO_ESTACION_SLIP_SENSOR_VALIDACION
                Select Case respuesta
                    Case 0
                        mensaje = "Sin papel"
                    Case 1
                        mensaje = "Con papel"
                End Select

            Case ESTADO_ESTACION_SLIP_SENSOR_TOF
                Select Case respuesta
                    Case 0
                        mensaje = "Sin papel"
                    Case 1
                        mensaje = "Con papel"
                End Select

            Case ESTADO_ESTACION_SLIP_SENSOR_BOF
                Select Case respuesta
                    Case 0
                        mensaje = "Sin papel"
                    Case 1
                        mensaje = "Con papel"
                End Select

            Case ESTADO_ESTACION_SLIP_VALIDACION_SENSOR_ESPERA
                Select Case respuesta
                    Case 0
                        mensaje = "Estado normal (sin espera)"
                    Case 1
                        mensaje = "A la espera de carga de papel"
                    Case 2
                        mensaje = "A la espera de remoción de papel"
                End Select

            Case ESTADO_ESTACION_SELECCIONADA
                Select Case respuesta
                    Case 0
                        mensaje = "Receipt (recibos)"
                    Case 1
                        mensaje = "Slip (hojas sueltas)"
                    Case 2
                        mensaje = "Validación"
                    Case 3
                        mensaje = "MICR"
                End Select

            Case ESTADO_CAJON_DINERO
                Select Case respuesta
                    Case 0
                        mensaje = "Cajón de dinero cerrado"
                    Case 1
                        mensaje = "Cajón de dinero abierto"
                End Select

            Case ESTADO_TAPA
                Select Case respuesta
                    Case 0
                        mensaje = "Tapa de impresora cerrada"
                    Case 1
                        mensaje = "Tapa de impresora abierta"
                End Select

            Case IMPRESORA_CON_ERROR
                Select Case respuesta
                    Case 0
                        mensaje = "Impresora sin error"
                    Case 1
                        mensaje = "Impresora con error"
                End Select

            Case IMPRESORA_EN_LINEA
                Select Case respuesta
                    Case 0
                        mensaje = "Impresora en línea (online)"
                    Case 1
                        mensaje = "Impresora fuera de línea (offline)"
                End Select

            Case ESTADO_CONEXION
                Select Case respuesta
                    Case 0
                        mensaje = "Sin Conexión"
                    Case 1
                        mensaje = "Equipo ocupado"
                    Case 2
                        mensaje = "Equipo disponible para comunicarse. (IDLE)"
                End Select

            Case Else
                Exit Sub
        End Select

        ' mostrar mensaje
        MostrarMensaje(retorno, "Tipo de estado: " & mensaje)
    End Sub

    Private Sub ObtenerEstadoFiscalDelEquipo()
        retorno = ObtenerEstadoFiscal()
        MostrarMensaje(ERROR_NINGUNO, "Estado fiscal: 0x" & String.Format("{0:X4}", retorno))
    End Sub

    Private Sub ObtenerEstadoDeImpresoraDelEquipo()
        retorno = ObtenerEstadoImpresora()
        MostrarMensaje(ERROR_NINGUNO, "Estado de impresora: 0x" & String.Format("{0:X4}", retorno))
    End Sub

    Private Sub ObtenerCodigoDelUltimoError()
        retorno = ConsultarUltimoError()
        MostrarMensaje(ERROR_NINGUNO, "Último error: 0x" & String.Format("{0:X4}", retorno))
    End Sub

    Private Sub ObtenerDescripcionDelCodigoDelUltimoError()
        Dim ultimo_error As Integer
        Dim respuesta As StringBuilder = New StringBuilder(MAX_DESCRIPTION)

        ' obtener ultimo error
        ultimo_error = ConsultarUltimoError()

        ' obtener descripcion del ultimo error 
        retorno = ConsultarDescripcionDeError(ultimo_error, respuesta, MAX_DESCRIPTION)

        ' mostrar mensaje
        MostrarMensaje(retorno, "Descipción del último error: " & respuesta.ToString())
    End Sub

    Private Sub ObtenerFechaHora()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarFechaHora(respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "Fecha / Hora en IF: " & respuesta.ToString)
    End Sub

    Private Sub SincronizarFechaHora()
        ' la sincronizacion de fecha y hora, se realiza enviando ningun valor en el parametro de entrada
        ' de la funcion de la DLL llamada EstablecerFechaHora().
        ' la Dll sincronizará la fecha y hora del RTC de la PC e intentará establecer la misma fecha y hora
        ' en el controlador fiscal (C.F.)
        NuevaFechaHora("")
    End Sub

    Private Sub EstablecerNuevaFechaHora()
        NuevaFechaHora(LblDateTimeNew.Text.Trim())
    End Sub

    Private Sub NuevaFechaHora(ByVal informacion As String)
        ' enviar comando
        retorno = EstablecerFechaHora(informacion)

        ' mostrar información
        If Len(informacion) <= 0 Then
            MostrarMensaje(retorno, "Fecha / Hora sincronizada.")
        Else
            MostrarMensaje(retorno, "Fecha / Hora establecida.")
        End If
    End Sub

    Private Sub EstablecerEncabezadosAlEquipo()
        Dim numero_str As String = ""
        Dim numero_int As Integer = 0

        ' obtener numero encabezado
        numero_str = cmbHeaderTrailerNumber.Text
        numero_int = Val(numero_str)

        ' ejecutar funcion
        retorno = EstablecerEncabezado(numero_int, txtHeaderTrailerDescription.Text)
        MostrarMensaje(retorno, "Encabezado número " & numero_str & " establecido ")
    End Sub

    Private Sub ObtenerEncabezadosDelEquipo()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim numero_str As String = ""
        Dim numero_int As Integer = 0

        ' obtener numero encabezado
        numero_str = cmbHeaderTrailerNumber.Text
        numero_int = Val(numero_str)

        ' ejecutar funcion
        retorno = ConsultarEncabezado(numero_int, respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "El encabezado número " & numero_str & " es: " & respuesta.ToString)

        ' mostrar en el label
        If retorno = ERROR_NINGUNO Then
            txtHeaderTrailerDescription.Text = respuesta.ToString
        End If
    End Sub

    Private Sub EstablecerColaAlEquipo()
        Dim numero_str As String = ""
        Dim numero_int As Integer = 0

        ' obtener numero encabezado
        numero_str = cmbHeaderTrailerNumber.Text
        numero_int = Val(numero_str)

        ' ejecutar funcion
        retorno = EstablecerCola(numero_int, txtHeaderTrailerDescription.Text)
        MostrarMensaje(retorno, "Cola número " & numero_str & " establecido ")
    End Sub

    Private Sub ObtenerColaDelEquipo()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim numero_str As String = ""
        Dim numero_int As Integer = 0

        ' obtener numero encabezado
        numero_str = cmbHeaderTrailerNumber.Text
        numero_int = Val(numero_str)

        ' ejecutar funcion
        retorno = ConsultarCola(numero_int, respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "La cola número " & numero_str & " es: " & respuesta.ToString)

        ' mostrar en el label
        If retorno = ERROR_NINGUNO Then
            txtHeaderTrailerDescription.Text = respuesta.ToString
        End If
    End Sub

    Private Sub AbrirDocumentoFiscal()
        Dim id As Integer
        Dim id_str As String

        ' get id Doc Fiscal
        id_str = cmbOpenVoucher.Text.Substring(0, 4)
        id = Val(id_str)

        ' abrir
        AbrirDocumento(id)
    End Sub

    Private Sub AbrirDocumento(ByVal id As Integer)
        ' abrir comprobante
        Select Case id
            Case 83  ' - Tique
                AbrirTique()
            Case 81  ' - Tique Factura A
                AbrirTiqueFactura_A()
            Case 82  ' - Tique Factura B
                AbrirTiqueFactura_B()
            Case 91  ' - DNFH Remito ‘R’
                AbrirDNFHValorizado(ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_REMITO_R)
            Case 110 ' - Tique Nota de Crédito
                AbrirTiqueNotaDeCredito()
            Case 111 ' - Tique Factura C
                AbrirTiqueFactura_C()
            Case 112 ' - Tique Nota de Crédito A
                AbrirTiqueNotaDeCredito_A()
            Case 113 ' - Tique Nota de Crédito B
                AbrirTiqueNotaDeCredito_B()
            Case 114 ' - Tique Nota de Crédito C
                AbrirTiqueNotaDeCredito_C()
            Case 115 ' - Tique Nota de Débito A
                AbrirTiqueNotaDeDebito_A()
            Case 116 ' - Tique Nota de Débito B
                AbrirTiqueNotaDeDebito_B()
            Case 117 ' - Tique Nota de Débito C
                AbrirTiqueNotaDeDebito_C()
            Case 118 ' - Tique Factura M
                AbrirTiqueFactura_A()
            Case 119 ' - Tique Nota de Crédito M
                AbrirTiqueNotaDeCredito_A()
            Case 120 ' - Tique Nota de Débito M
                AbrirTiqueNotaDeDebito_A()
            Case 901 ' - DNFH Remito ‘X’
                AbrirDNFHValorizado(ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_REMITO_X)
            Case 902 ' - DNFH Recibo ‘X’
                AbrirDNFHValorizado(ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_RECIBO_X)
            Case 903 ' - DNFH Presupuesto ‘X’
                AbrirDNFHValorizado(ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_PRESUPUESTO_X)
            Case 907 ' - DNFH Comprobante Donación
                AbrirDNFHValorizado(ID_TIPO_COMPROBANTE_DNFH_VALORIZADO_DONACION)
            Case 910 ' - DNFH Documento Generico 
                AbrirDocumentoDNFHGenerico(ID_TIPO_COMPROBANTE_DNFH_GENERIC)
            Case 950 ' - DNFH Documento de uso interno  
                AbrirDocumentoDNFHGenerico(ID_TIPO_COMPROBANTE_DNFH_INTERNAL_USE)
            Case Else
                Exit Sub
        End Select
    End Sub

    Private Sub AbrirTique()
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUET)
        MostrarMensaje(retorno, "Tiquet abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeCredito()
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_CREDITO)
        MostrarMensaje(retorno, "Tiquet nota de credito abierto.")
    End Sub

    Private Sub AbrirTiqueFactura_A()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_RESPONSABLE_INSCRIPTO)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_FACTURA)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueFactura_B()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_FACTURA)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueFactura_C()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_FACTURA)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeCredito_A()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_RESPONSABLE_INSCRIPTO)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_CREDITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeCredito_B()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_CREDITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeCredito_C()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_CREDITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeDebito_A()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_RESPONSABLE_INSCRIPTO)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_DEBITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeDebito_B()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_DEBITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirTiqueNotaDeDebito_C()
        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_MONOTRIBUTISTA)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(ID_TIPO_COMPROBANTE_TIQUE_NOTA_DE_DEBITO)
        MostrarMensaje(retorno, "Tiquet factura abierto.")
    End Sub

    Private Sub AbrirDNFHValorizado(ByVal id As Integer)

        ' **********************************************************************************************
        ' Nota:  en la version Dll 2.3.0  --> no se encuentran soportado la emisión de DNFH valorizados.
        ' **********************************************************************************************


        ' Datos del cliente 
        retorno = CargarDatosCliente("Nombre Comprador #1", "Nombre Comprador #2", "Domicilio Comprador #1", "Domicilio Comprador #2", "Domicilio Comprador #3", ID_TIPO_DOCUMENTO_CUIT, "24272242549", ID_RESPONSABILIDAD_IVA_RESPONSABLE_INSCRIPTO)
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarDatosCliente()")
            Exit Sub
        End If

        ' Comprobante asociado
        retorno = CargarComprobanteAsociado("083-00001-00000027")
        If retorno <> ERROR_NINGUNO Then
            MostrarMensaje(retorno, "Error en función CargarComprobanteAsociado()")
            Exit Sub
        End If

        ' Apertura del comprobante
        retorno = AbrirComprobante(id)
        MostrarMensaje(retorno, "DNFH valorizado abierto.")
    End Sub

    Private Sub AbrirDocumentoDNFHGenerico(ByVal id As Integer)
        retorno = AbrirComprobante(id)
        MostrarMensaje(retorno, "DNFH generico abierto.")
    End Sub

    Private Sub AlmacenarDescripcionExtra()
        retorno = CargarTextoExtra("Dato extra")
        MostrarMensaje(retorno, "Línea de descripción extra almacenada.")
    End Sub

    Private Sub ItemVenta()
        retorno = ImprimirItem(ID_MODIFICADOR_AGREGAR, "Pizza fugazzeta grande", "1.000", "300.0000", ID_TASA_IVA_21_00, ID_IMPUESTO_NINGUNO, "", ID_CODIGO_INTERNO, "1234567890", "", AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO)

        ' IIfijo: IMPUESTO INTERNO FIJO (ejemplo)
        'retorno = ImprimirItem(ID_MODIFICADOR_AGREGAR, "con IIfijo 2pesos", "1.000", "300.0000", ID_TASA_IVA_21_00, ID_IMPUESTO_INTERNO_FIJO, "2.0000", ID_CODIGO_INTERNO, "1234567890", "", AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO)

        ' II%: IMPUESTO INTERNO PORCENCUAL (ejemplo)
        'retorno = ImprimirItem(ID_MODIFICADOR_AGREGAR, "con II%", "1.000", "300.0000", ID_TASA_IVA_21_00, ID_IMPUESTO_INTERNO_PORCENTUAL, "0.14250000", ID_CODIGO_INTERNO, "1234567890", "", AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO)

        MostrarMensaje(retorno, "Ítem vendido.")
    End Sub

    Private Sub CancelarVenta()
        Call CancelarTodo()
    End Sub

    Private Sub CancelarTodo()
        retorno = Cancelar()
        MostrarMensaje(retorno, "Cancelada la operación en proceso.")
    End Sub


    Private Sub Bonificar()
        retorno = ImprimirItem(ID_MODIFICADOR_AGREGAR_ITEM_BONIFICACION, "Descuento mes feliz", "1.000", "10.0000", ID_TASA_IVA_21_00, ID_IMPUESTO_NINGUNO, "", ID_CODIGO_INTERNO, "1234567890", "", AFIP_CODIGO_UNIDAD_MEDIDA_KILOGRAMO)
        MostrarMensaje(retorno, "Bonificación.")
    End Sub

    Private Sub PagarTdC()
        retorno = CargarPago(ID_MODIFICADOR_AGREGAR, AFIP_CODIGO_FORMA_DE_PAGO_TARJETA_DE_CREDITO, 3, "500.00", "", "AMEX", "", "")
        MostrarMensaje(retorno, "Pago almacenado.")
    End Sub

    Private Sub ObtenerSubtotal()
        retorno = ImprimirSubtotal()
        MostrarMensaje(retorno, "Subtotal impreso.")
    End Sub

    Private Sub AjustePositivo()
        retorno = CargarAjuste(ID_MODIFICADOR_AJUSTE, "Ajuste positivo", "10.1", ID_TASA_IVA_NINGUNO, "CodigoInterno4567890123456789012345678901234567890")
        MostrarMensaje(retorno, "Ajuste positivo cargado.")
    End Sub

    Private Sub AjusteNegativo()
        retorno = CargarAjuste(ID_MODIFICADOR_AJUSTE_NEGATIVO, "Ajuste negativo", "2.1", ID_TASA_IVA_NINGUNO, "CodigoInterno4567890123456789012345678901234567890")
        MostrarMensaje(retorno, "Ajuste negtivo cargado.")

    End Sub

    Private Sub Descuento(ByVal descuento_por_IVA As Boolean)
        Dim str As String = ""
        Dim tasa_de_iva As Integer

        ' armando el string
        If descuento_por_IVA = True Then
            str = "Descuento por IVA"
            tasa_de_iva = ID_TASA_IVA_21_00
        Else
            str = "Descuento global"
            tasa_de_iva = ID_TASA_IVA_NINGUNO
        End If

        ' ejecutar funcion
        retorno = CargarAjuste(ID_MODIFICADOR_DESCUENTO, str, ".123", tasa_de_iva, "CodigoInterno4567890123456789012345678901234567890")
        MostrarMensaje(retorno, str & " cargado")
    End Sub


    Private Sub OtrosTributos_incluye_a_las_Percepciones()
        ' Percepcion por Tasa de IVA
        retorno = CargarOtrosTributos(AFIP_CODIGO_OTROS_TRIBUTOS_PERCEPCION_DE_IVA, "Percepcion por Tasa de IVA", "10.00", ID_TASA_IVA_21_00)
        MostrarMensaje(retorno, "Percepcion por Tasa de IVA, cargado")

        ' Otra Percepcion
        retorno = CargarOtrosTributos(AFIP_CODIGO_OTROS_TRIBUTOS_OTRAS_PERCEPCIONES, "Otra Percepcion", "5.00", ID_TASA_IVA_NINGUNO)
        MostrarMensaje(retorno, "Otra Percepcion, cargado")

        ' Percepcion de IIBB
        retorno = CargarOtrosTributos(AFIP_CODIGO_OTROS_TRIBUTOS_PERCEPCION_DE_INGRESOS_BRUTOS, "Percepcion de IIBB", "3.00", ID_TASA_IVA_NINGUNO)
        MostrarMensaje(retorno, "Percepcion de IIBB, cargado")
    End Sub

    Private Sub ObtenerSubtotal(ByVal subtotal_bruto As Boolean)
        Dim str As String = ""
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        ' ejecutar funcion
        If subtotal_bruto = True Then
            str = "El subtotal bruto es: $"
            retorno = ConsultarSubTotalBrutoComprobanteActual(respuesta, MAX_ANSWER)
        Else
            str = "El subtotal neto es: $"
            retorno = ConsultarSubTotalNetoComprobanteActual(respuesta, MAX_ANSWER)
        End If

        ' mostrar mensaje
        MostrarMensaje(retorno, str & respuesta.ToString)
    End Sub

    Private Function CerrarCualquierDocumentoEnCurso() As Integer
        retorno = CerrarComprobante()
        CerrarCualquierDocumentoEnCurso = retorno
    End Function

    Private Sub TextoLibreEnDNFHGenerico(ByVal cantidad_de_lineas As Integer)
        Dim str_linea As String = ""

        For n As Integer = 1 To cantidad_de_lineas
            str_linea = "Texto Libre #" & n.ToString()

            retorno = ImprimirTextoLibre(str_linea)
            MostrarMensaje(retorno, str_linea)
        Next
    End Sub

    Private Function ObtenerNroComprobanteEnCurso() As String
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarNumeroComprobanteActual(respuesta, MAX_ANSWER)
        Return respuesta.ToString
    End Function
    Private Function ObtenerNroComprobanteUltimo(ByVal tipo_de_comprobante As String) As String
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarNumeroComprobanteUltimo(tipo_de_comprobante, respuesta, MAX_ANSWER)
        Return respuesta.ToString
    End Function

    Private Sub ReiniciarBarraDeEstado()
        ToolStripStatusLabel1.Text = "                Epson Latin America                "
        ToolStripStatusLabel2.Text = "     ---     "
        ToolStripStatusLabel3.Text = "     ---     "
        ToolStripStatusLabel4.Text = "     ---     "
    End Sub

    Private Sub AuditoriaResumidaXRangoZ()
        retorno = ImprimirAuditoria(ID_MODIFICADOR_AUDITORIA_RESUMIDA, txtFrom.Text, txtTo.Text)
        MostrarMensaje(retorno, "Informe de auditoría resumida entre Z #" & txtFrom.Text & " y Z #" & txtTo.Text)
    End Sub

    Private Sub PermitirEliminacionDeDescargasRealizadas()
        ' aplicar la funcion, fomrato:   ddmmyy  -->  "010140": es primero de enero de 2040
        retorno = ConfimarDescarga("010140")

        ' termino la operacion de la funcion de la dll llamada "ConfimarDescarga()"
        MostrarMensaje(retorno, "Comando para permitir eliminar descargas realizadas ejecutado.")
    End Sub

    Private Sub ConsultarInformacionDeDescargas()
        Dim mensaje As String = ""

        Dim respuesta_periodo_pendiente As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim respuesta_periodo_descargado As StringBuilder = New StringBuilder(MAX_ANSWER)
        Dim respuesta_periodo_eliminado As StringBuilder = New StringBuilder(MAX_ANSWER)

        ' ejecutar funcion
        retorno = ConsultarFechaPrimerJornadaPendiente(respuesta_periodo_pendiente, 20)

        ' armar mensaje 
        mensaje = "Fecha Período pendiente: " & respuesta_periodo_pendiente.ToString()

        ' mostrar mensaje
        MostrarMensaje(retorno, "Información de descargas: " & vbLf & mensaje)
    End Sub

    Private Sub DescargarElPeriodoPendiente()
        ' crear directorio
        My.Computer.FileSystem.CreateDirectory("c:\\descargas")

        ' ejecutar funcion
        retorno = DescargarPeriodoPendiente("c:\\descargas")
        MostrarMensaje(retorno, "Descarga período pendiente realizadas. Ver carpeta c:\descargas")
    End Sub

    Private Sub VerXMLdentroDelArchivoPuntoPEMDescargadoMedianteDecodificacion()
        ' obtener el nombre del primer archivo .pem del directorio ("c:\\descargas")
        Dim path As String = "c:\\descargas"
        Dim di
        Try
            di = New IO.DirectoryInfo(path)
        Catch
            ' Error, nada por hacer
            Return
        End Try

        Dim aryFi As IO.FileInfo() = di.GetFiles("*.pem")
        Dim fi As IO.FileInfo
        Dim one_file As String = ""
        Dim strFileSize As String = ""
        Dim strFileName As String = ""

        For Each fi In aryFi
            strFileSize = (Math.Round(fi.Length / 1024)).ToString()
            one_file = "" & fi.Name ' & " " & fi.FullName & " " & strFileSize & " " & fi.Extension & " " & fi.LastAccessTime
            Exit For
        Next

        If one_file.Length <= 0 Then
            Return  ' No hay archivos, nada por hacer
        End If

        strFileName = My.Computer.FileSystem.CombinePath(path, one_file)


        ' decodificar archivo .pem
        Dim xml As String = ""
        Dim xml_cancel As Boolean = False
        xml = decode_file_cms(strFileName, xml_cancel)   '  <--- FUNCION IMPORTANTE A UTILIZAR:  decode_file_cms()

        ' mostar xml decodificado
        MessageBox.Show(xml, "Archivo: " & strFileName)

    End Sub

    Private Function decode_file_cms(ByVal file_name As String, ByRef cancel As Boolean) As String
        ' USAR ESTA FUNCIÓN PARA DECODIFICAR (ABRIR) EL ARCHIVO .PEM DESCARGADO
        ' ESTO SE ENCUENTRA SOPORTADO DESDE .NET 4.0
        '
        ' SE DEBE HACER LAS SIGUIENTES IMPORTACIONES:
        '
        '                                              Imports System.IO
        '                                              Imports System.Security.Cryptography
        '                                              Imports System.Security.Cryptography.Pkcs
        '                                              Imports System.Security.Cryptography.X509Certificates
        '
        ' Y AGREGAR "System.Security"  en las referencias.
        '
        ' Saludos cordiales:  RUBEN PANTALEON MIRANDA -  rpm+


        ' definir objecto CMS
        Dim cms As System.Security.Cryptography.Pkcs.SignedCms = New System.Security.Cryptography.Pkcs.SignedCms()

        ' leer el archivo como un string
        Dim info As String = File.ReadAllText(file_name)

        ' quitar los valores que no deseamos del archivo
        info = info.Replace("\n", "").Replace("-----BEGIN CMS-----", "").Replace("-----END CMS-----", "")

        ' decodificar (abrir la información que contiene)
        Try
            cms.Decode(Convert.FromBase64String(info))
        Catch
            ' retornar hasta donde esta la información
            cancel = True
            Return "" & vbLf & " ¡¡¡CANCELADO!!!" & vbLf & vbLf & "    Formato inválido.-"
        End Try

        ' convierto la información a un string 
        Dim s As String
        Dim info_return As String = ""
        For index As Integer = 0 To cms.ContentInfo.Content.Length - 1
            ' verificar cancelacion
            If cancel = True Then
                ' retornar hasta donde esta la información
                info_return = "" & vbLf & " ¡¡¡CANCELADO!!!" & vbLf & vbLf & info_return
                Return info_return
            End If

            ' convertir
            s = Convert.ToString(cms.ContentInfo.Content(index)).ToString()
            info_return = info_return + Chr(s).ToString()
        Next

        ' retorna la información
        Return info_return

    End Function

    Private Sub DescargarXRangoZ()
        ' crear directorio
        My.Computer.FileSystem.CreateDirectory("c:\\descargas")

        ' ejecutar funcion
        retorno = Descargar(txtFrom.Text, txtTo.Text, "c:\\descargas")
        MostrarMensaje(retorno, "Descargas entre Z #" & txtFrom.Text & " y Z #" & txtTo.Text & " realizadas. Ver carpeta c:\descargas")
    End Sub

    Private Sub AuditoriaResumidaXRangoZPorFecha()
        retorno = ImprimirAuditoria(ID_MODIFICADOR_AUDITORIA_RESUMIDA, txtFrom_date.Text, txtTo_date.Text)
        MostrarMensaje(retorno, "Informe de auditoría resumida entre fecha: " & txtFrom_date.Text & " y fecha: " & txtTo_date.Text)
    End Sub

    Private Sub DescargarXRangoZPorFecha()
        ' crear directorio
        My.Computer.FileSystem.CreateDirectory("c:\\descargas")

        ' ejecutar funcion
        retorno = Descargar(txtFrom_date.Text, txtTo_date.Text, "c:\\descargas")
        MostrarMensaje(retorno, "Descargas entre fecha: " & txtFrom_date.Text & " y fecha: " & txtTo_date.Text & " realizadas. Ver carpeta c:\descargas")
    End Sub

    Private Sub AvanzarPapel(ByVal n As String)
        Dim comando As StringBuilder = New StringBuilder(MAX_COMMAND)

        comando.Append("0701|0000|" & n)
        retorno = EnviarComando(comando.ToString)
        MostrarMensaje(retorno, "Rollo de papel avanzó " & n.ToString & " líneas.")
    End Sub

    Private Sub CortarPapel()
        Dim comando As StringBuilder = New StringBuilder(MAX_COMMAND)

        comando.Append("0702|0000")
        retorno = EnviarComando(comando.ToString)
        MostrarMensaje(retorno, "Rollo de papel cortado.")
    End Sub

    Private Sub AbrirCajon1()
        Dim comando As StringBuilder = New StringBuilder(MAX_COMMAND)

        comando.Append("0707|0000")
        retorno = EnviarComando(comando.ToString)
        MostrarMensaje(retorno, "Enviado el pulso para abrir cajón de dinero #1.")
    End Sub

    Private Sub ConsultarTipoComprobante()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarTipoComprobanteActual(respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "Tipo de Documento en progreso: " & respuesta.ToString)
    End Sub

    Private Sub ConsultarNumeroDeComprobante()
        Dim respuesta As StringBuilder = New StringBuilder(MAX_ANSWER)

        retorno = ConsultarNumeroComprobanteActual(respuesta, MAX_ANSWER)
        MostrarMensaje(retorno, "Número de Documento en progreso: " & respuesta.ToString)
    End Sub

    Private Sub ObtenerEstadoJornada()
        Dim respuesta As Integer
        Dim mensaje As String = "ABIERTA"

        retorno = ConsultarEstado(JORNADA_FISCAL, respuesta)
        If respuesta = 0 Then mensaje = "CERRADA"
        MostrarMensaje(retorno, "Jornada fiscal: " & mensaje)
    End Sub

    Private Sub ObtenerModoFuncionamiento()
        Dim respuesta As Integer
        Dim mensaje As String = ""

        retorno = ConsultarEstado(MODO_FUNCIONAMIENTO_EQUIPO, respuesta)
        Select Case respuesta
            Case 0
                mensaje = "BLOQUEADO POR SOFTWARE"
            Case 1
                mensaje = "MODO MANUFACTURA"
            Case 2
                mensaje = "MODO ENTRENAMIENTO"
            Case 3
                mensaje = "MODO FISCAL"
            Case 15
                mensaje = "BLOQUEO POR HARDWARE"
        End Select

        MostrarMensaje(retorno, "Modo de funcionamiento: " & mensaje)
    End Sub

    Private Sub AlmacenarLogoFiscal()
        ' mostrar pregunta
        Dim result As DialogResult = MessageBox.Show("¿Desea cargar logo de comercio?" & vbCrLf & vbCrLf & "Ruta: " & AlmacenarLogoFiscalNombre, "Confirmar", MessageBoxButtons.YesNo)

        ' evaluar pregunta
        If (result = DialogResult.Yes) Then
            ' START LOGO
            almacenar_logo_fiscal_start()
        Else
            Exit Sub
        End If

    End Sub

    Public Sub almacenar_logo_fiscal_start()
        ' efecto visual: progress bar iniciar
        progressLoadLogo.Style = ProgressBarStyle.Marquee

        ' efecto visual: paneles off
        DeshabilitarPaneles()
        GroupBox1.Enabled = False

        ' creando el hilo para ejecucion en segundo plano y lanzando el hilo
        AlmacenarLogoFiscalThread = New Thread(AlmacenarLogoFiscalThreadStart)
        AlmacenarLogoFiscalThread.IsBackground = True
        AlmacenarLogoFiscalThread.Start()  ' lanza el hilo llamando a la funcion AlmacenarLogoFiscalThreadSegundoPlano()
    End Sub

    Public Sub AlmacenarLogoFiscalThreadSegundoPlano()
        ' Nota: la función CargarLogo()  es bloqueante, pero como se encuentra
        '       en un hilo en segundo plano, la GUI se continua refrescando
        retorno = CargarLogo(AlmacenarLogoFiscalNombre)

        ' actualiza la GUI
        Me.BeginInvoke(AlmacenarLogoFiscalDeleteChangeGUI)
        Thread.Sleep(500)
    End Sub

    Public Sub AlmacenarLogoFiscalActualizarGUI()
        ' STOP LOGO
        almacenar_logo_fiscal_stop()
    End Sub

    Public Sub almacenar_logo_fiscal_stop()
        ' efecto visual: progress bar detener
        progressLoadLogo.Style = ProgressBarStyle.Continuous

        ' mostrar mensaje en el log
        MostrarMensaje(retorno, "Logo de comercio almacenado.")

        ' efecto visual: paneles on
        HabilitarPaneles()
        GroupBox1.Enabled = True

        ' deteniendo el hilo
        AlmacenarLogoFiscalThread.Abort()
    End Sub

    Private Sub EliminarLogoFiscal()
        retorno = EliminarLogo()
        MostrarMensaje(retorno, "Logo de comercio eliminado.")
    End Sub

    Private Sub ObtenerDatosFIscalizacion()
        Dim comando As StringBuilder = New StringBuilder(MAX_COMMAND)

        comando.Append("0507|0001")
        retorno = EnviarComando(comando.ToString)

        MostrarMensaje(retorno, "Datos de fiscalización impresos.")
    End Sub

    Sub AgregarVersionDllEnToolbar(ByVal version_dll As String)
        Const PATTERN As String = "Epson Fiscal Interface dynamic library:"

        Dim str_version As String
        Dim str_pos_ini As Integer

        ' init
        str_version = ""
        str_pos_ini = 1
        str_pos_ini = InStr(1, version_dll, PATTERN)
        str_version = version_dll.Substring(str_pos_ini + Len(PATTERN), 5)

        ' mostrar en toolbar
        ToolStripStatusLabel4.Text = "Dll versión: v.: " + str_version
    End Sub

    Private Sub btnDeleteLogo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteLogo.Click
        Call EliminarLogoFiscal()
    End Sub

    Private Sub btnTckInvDescription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call AlmacenarDescripcionExtra()
    End Sub

    Private Sub btnTckInvItemUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call ItemVenta()
    End Sub

    Private Sub btnTckInvItemDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call Bonificar()
    End Sub

    Private Sub btnTckInvCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call CancelarVenta()
    End Sub

    Private Sub btnTckInvSubtotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call ObtenerSubtotal()
    End Sub

    Private Sub btnTckInvPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call PagarTdC()
    End Sub

    Private Sub btnTckInvClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call CerrarCualquierDocumentoEnCurso()
    End Sub

    Private Sub btnGetLastVoucherNumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetLastVoucherNumber.Click
        ' get id Doc Fiscal
        Dim id_str As String
        id_str = cmbOpenVoucher.Text.Substring(0, 4)

        ' ejecutar funcion
        Dim nroComp As String
        nroComp = ObtenerNroComprobanteUltimo(id_str.Trim())
        MostrarMensaje(retorno, "Número último Comprobante (" & id_str.Trim() & ") : " & nroComp)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_X.Click
        Call EnviarComandoGenerico_ImprimirX_con_preferencias_particulares()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpliftPositiveGlobal.Click
        Call AjustePositivo()
    End Sub

    Private Sub GroupBox4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub btnQueryOfDocInProgress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQueryOfDocInProgress.Click

        ' *********************************************************************
        ' ** IMPLEMENTACIÓN A FUTURO, CON LA LIBERACION DE LAS PROXIMAS DLLs **
        ' *********************************************************************

    End Sub

    Private Sub btnClose_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose_DNFH.Click
        retorno = CerrarCualquierDocumentoEnCurso()
        MostrarMensaje(retorno, "Comprobante cerrado")
    End Sub
    Private Sub btnGetLastVoucherNumber_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetLastVoucherNumber_DNFH.Click
        ' get id Doc Fiscal
        Dim id_str As String
        id_str = cmbOpenVoucherDNFH.Text.Substring(0, 4)

        ' ejecutar funcion
        Dim nroComp As String
        nroComp = ObtenerNroComprobanteUltimo(id_str.Trim())
        MostrarMensaje(retorno, "Número último Comprobante (" & id_str.Trim() & ") : " & nroComp)
    End Sub
    Private Sub btnQueryOfDocInProgress_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQueryOfDocInProgress_DNFH.Click

        ' *********************************************************************
        ' ** IMPLEMENTACIÓN A FUTURO, CON LA LIBERACION DE LAS PROXIMAS DLLs **
        ' *********************************************************************

    End Sub

    Private Sub btnPrefernces_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrefernces_DNFH.Click

        ' *********************************************************************
        ' ** IMPLEMENTACIÓN A FUTURO, CON LA LIBERACION DE LAS PROXIMAS DLLs **
        ' *********************************************************************

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ctrlRichTextBoxLog.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call ObtenerPuntoDeVenta()
    End Sub

    Private Sub btnGetTypeStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetTypeStatus.Click
        Call ObtenerEstadoDeterminado()
    End Sub

    Private Sub btnFiscalStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFiscalStatus.Click
        Call ObtenerEstadoFiscalDelEquipo()
    End Sub

    Private Sub btnPrinterStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrinterStatus.Click
        Call ObtenerEstadoDeImpresoraDelEquipo()
    End Sub

    Private Sub btnLastError_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLastError.Click
        Call ObtenerCodigoDelUltimoError()
    End Sub

    Private Sub btnErrorDescription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnErrorDescription.Click
        Call ObtenerDescripcionDelCodigoDelUltimoError()
    End Sub

    Private Sub btnSetHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetHeader.Click
        Call EstablecerEncabezadosAlEquipo()
    End Sub

    Private Sub btnGetHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetHeader.Click
        Call ObtenerEncabezadosDelEquipo()
    End Sub

    Private Sub btnSetTrailer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetTrailer.Click
        Call EstablecerColaAlEquipo()
    End Sub

    Private Sub btnGetTrailer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetTrailer.Click
        Call ObtenerColaDelEquipo()
    End Sub

    Private Sub btnUpliftNegativeGlobal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpliftNegativeGlobal.Click
        Call AjusteNegativo()
    End Sub

    Private Sub btnDiscountGlobal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiscountGlobal.Click
        Call Descuento(False)
    End Sub

    Private Sub btnDiscountByIVA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiscountByIVA.Click
        Call Descuento(True)
    End Sub

    Private Sub btnOtherTax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOtherTax.Click
        Call OtrosTributos_incluye_a_las_Percepciones()
    End Sub

    Private Sub btnSubtotalGross_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubtotalGross.Click
        Call ObtenerSubtotal(True)
    End Sub

    Private Sub btnSubtotalNet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubtotalNet.Click
        Call ObtenerSubtotal(False)
    End Sub

    Private Sub btnDocNumberInProgress_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDocNumberInProgress.Click
        Call ConsultarNumeroDeComprobante()
    End Sub

    Private Sub btnPrefernces_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrefernces.Click

        ' *********************************************************************
        ' ** IMPLEMENTACIÓN A FUTURO, CON LA LIBERACION DE LAS PROXIMAS DLLs **
        ' *********************************************************************

    End Sub

    Private Sub btnOpen_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen_DNFH.Click
        Dim id As Integer
        Dim id_str As String

        ' get id Doc Fiscal
        id_str = cmbOpenVoucherDNFH.Text.Substring(0, 4)
        id = Val(id_str)

        ' abrir documento
        Call AbrirDocumento(id)
    End Sub

    Private Sub btnFreeLine_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFreeLine_DNFH.Click
        Call TextoLibreEnDNFHGenerico(1)
    End Sub

    Private Sub btn_MultiFreeLine_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_MultiFreeLine_DNFH.Click
        TextoLibreEnDNFHGenerico(80)
    End Sub


    Private Sub btnGenericCommand_TechnicalTticket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_TechnicalTticket.Click
        Call EnviarComandoGenerico_Imprimir_tique_tecnico()
    End Sub

    Private Sub btnLoadLogoBrowser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadLogoBrowser.Click

        Dim fd As OpenFileDialog = New OpenFileDialog()
        Dim strFileName As String

        fd.Title = "Elegir logo de usuario"
        fd.InitialDirectory = My.Computer.FileSystem.CombinePath(System.AppDomain.CurrentDomain.BaseDirectory().ToString(), "logo")
        fd.Filter = "PNG Imagen (*.PNG)|*.PNG|PNG Imagen (*.PNG)|*.PNG"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName

            ' guardar logo en varible global
            AlmacenarLogoFiscalNombre = strFileName
        End If


    End Sub

    Private Sub btnCancel_DNFH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel_DNFH.Click
        Call CancelarTodo()
    End Sub

    Private Sub btnDownloadPeriodPending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownloadPeriodPending.Click
        ' descargar
        Call DescargarElPeriodoPendiente()

        ' mostrar directorio donde estan las descargas
        If retorno = ERROR_NINGUNO Then
            System.Diagnostics.Process.Start("c:\\descargas")
        End If
    End Sub

    Private Sub btnDownloadPeriodDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownloadPeriodDelete.Click
        Call PermitirEliminacionDeDescargasRealizadas()
    End Sub

    Private Sub btnDownloadGetInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDownloadGetInfo.Click
        Call ConsultarInformacionDeDescargas()
    End Sub

    Private Sub btnDateTimeGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDateTimeGet.Click
        Call ObtenerFechaHora()
    End Sub

    Private Sub btnDateTimeSync_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDateTimeSync.Click
        Call SincronizarFechaHora()
    End Sub

    Private Sub btnDateTimeNewSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDateTimeNewSet.Click
        Call EstablecerNuevaFechaHora()
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Call VerXMLdentroDelArchivoPuntoPEMDescargadoMedianteDecodificacion()
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Call EnviarComandoGenerico_ObtenerInfoJornadaParaTicket()
    End Sub

    Private Sub btnGenericCommand_get_fiscal_status_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_get_fiscal_status.Click
        Call EnviarComandoGenerico_get_fiscal_status()
    End Sub

    Private Sub btnGenericCommand_get_printer_status_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_get_printer_status.Click
        Call EnviarComandoGenerico_get_printer_status()
    End Sub

    Private Sub btnGenericCommand_get_return_code_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_get_return_code.Click
        Call EnviarComandoGenerico_get_return_code()
    End Sub

    Private Sub btnGenericCommand_get_qty_output_fields_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGenericCommand_get_qty_output_fields.Click
        Call EnviarComandoGenerico_get_qty_output_fields()
    End Sub

    Private Sub chckEnable_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chckEnable.CheckStateChanged
        Return
    End Sub

    Private Sub btnShowLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowLog.Click
        ' Obtener nombre del archivo
        Dim file As String = Application.ExecutablePath
        Dim file_log = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(file), System.IO.Path.GetFileNameWithoutExtension(file))

        ' modo debug or release?
        Dim isDebugMode As Boolean = False
        If Debugger.IsAttached Then
            file_log = file_log & ".vshost"    ' agregar que es un archivo en modo debug
        End If

        ' agrega la extension .log
        file_log = file_log & ".log"

        ' Mostrar archivo
        Try
            System.Diagnostics.Process.Start(file_log)
        Catch
            MsgLogAgregar("Archivo de log no encontrado." & vbCrLf & "Nombre de archivo: " & file_log, MsgBoxStyle.Exclamation, "Error!")
        End Try

    End Sub
End Class
