﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormInit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.labelVersion = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnDisconnect = New System.Windows.Forms.Button()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.cmbBaudRate = New System.Windows.Forms.ComboBox()
        Me.cmbPort = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnZ = New System.Windows.Forms.Button()
        Me.btnX = New System.Windows.Forms.Button()
        Me.btnDllVersion = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnErrorDescription = New System.Windows.Forms.Button()
        Me.btnLastError = New System.Windows.Forms.Button()
        Me.btnPrinterStatus = New System.Windows.Forms.Button()
        Me.btnFiscalStatus = New System.Windows.Forms.Button()
        Me.btnGetTypeStatus = New System.Windows.Forms.Button()
        Me.cmbGetTypeStatus = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnOperatingMode = New System.Windows.Forms.Button()
        Me.btnGetDateTime = New System.Windows.Forms.Button()
        Me.btnFiscalDay = New System.Windows.Forms.Button()
        Me.btnGetFPVersion = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.btnGetFiscalizationData = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnPrefernces = New System.Windows.Forms.Button()
        Me.cmbQueryOfDocInProgress = New System.Windows.Forms.ComboBox()
        Me.btnQueryOfDocInProgress = New System.Windows.Forms.Button()
        Me.btnDocInProgress = New System.Windows.Forms.Button()
        Me.btnDocNumberInProgress = New System.Windows.Forms.Button()
        Me.btnSubtotalNet = New System.Windows.Forms.Button()
        Me.btnSubtotalGross = New System.Windows.Forms.Button()
        Me.btnOtherTax = New System.Windows.Forms.Button()
        Me.btnDiscountByIVA = New System.Windows.Forms.Button()
        Me.btnUpliftNegativeGlobal = New System.Windows.Forms.Button()
        Me.btnDiscountGlobal = New System.Windows.Forms.Button()
        Me.btnUpliftPositiveGlobal = New System.Windows.Forms.Button()
        Me.cmbOpenVoucher = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnGetLastVoucherNumber = New System.Windows.Forms.Button()
        Me.btnExtraDescription = New System.Windows.Forms.Button()
        Me.btnItemDown = New System.Windows.Forms.Button()
        Me.btnSubtotal = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnPayment = New System.Windows.Forms.Button()
        Me.btnItemUp = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOpen = New System.Windows.Forms.Button()
        Me.btnGetTrailer = New System.Windows.Forms.Button()
        Me.btnSetTrailer = New System.Windows.Forms.Button()
        Me.btnGetHeader = New System.Windows.Forms.Button()
        Me.btnSetHeader = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnLoadLogoBrowser = New System.Windows.Forms.Button()
        Me.btnDownloadPeriodPending = New System.Windows.Forms.Button()
        Me.btnDownloadPeriodDelete = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnCutPaper = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.progressLoadLogo = New System.Windows.Forms.ToolStripProgressBar()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnDownloadGetInfo = New System.Windows.Forms.Button()
        Me.rdbtnByDate = New System.Windows.Forms.RadioButton()
        Me.txtTo_date = New System.Windows.Forms.TextBox()
        Me.txtFrom_date = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.rdbtnByClosureZ = New System.Windows.Forms.RadioButton()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.btnAudit = New System.Windows.Forms.Button()
        Me.txtTo = New System.Windows.Forms.TextBox()
        Me.txtFrom = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnLoadLogo = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtHeaderTrailerDescription = New System.Windows.Forms.TextBox()
        Me.cmbHeaderTrailerNumber = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btnDeleteLogo = New System.Windows.Forms.Button()
        Me.btnFeedPaper = New System.Windows.Forms.Button()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ctrlRichTextBoxLog = New System.Windows.Forms.RichTextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.btnCancel_DNFH = New System.Windows.Forms.Button()
        Me.btnPrefernces_DNFH = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbQueryOfDocInProgress_DNFH = New System.Windows.Forms.ComboBox()
        Me.btnQueryOfDocInProgress_DNFH = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnGetLastVoucherNumber_DNFH = New System.Windows.Forms.Button()
        Me.btnClose_DNFH = New System.Windows.Forms.Button()
        Me.btn_MultiFreeLine_DNFH = New System.Windows.Forms.Button()
        Me.btnOpen_DNFH = New System.Windows.Forms.Button()
        Me.btnFreeLine_DNFH = New System.Windows.Forms.Button()
        Me.cmbOpenVoucherDNFH = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.btnGenericCommand_get_qty_output_fields = New System.Windows.Forms.Button()
        Me.btnGenericCommand_get_return_code = New System.Windows.Forms.Button()
        Me.btnGenericCommand_get_printer_status = New System.Windows.Forms.Button()
        Me.btnGenericCommand_get_fiscal_status = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnGenericCommand_TechnicalTticket = New System.Windows.Forms.Button()
        Me.btnGenericCommand_X = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.btnDateTimeNewSet = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.LblDateTimeNew = New System.Windows.Forms.TextBox()
        Me.btnDateTimeSync = New System.Windows.Forms.Button()
        Me.btnDateTimeGet = New System.Windows.Forms.Button()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.chckEnable = New System.Windows.Forms.CheckBox()
        Me.btnShowLog = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.labelVersion)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.btnDisconnect)
        Me.GroupBox1.Controls.Add(Me.btnConnect)
        Me.GroupBox1.Controls.Add(Me.cmbBaudRate)
        Me.GroupBox1.Controls.Add(Me.cmbPort)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Location = New System.Drawing.Point(3, -1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1128, 42)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Configuración"
        '
        'labelVersion
        '
        Me.labelVersion.AutoSize = True
        Me.labelVersion.ForeColor = System.Drawing.Color.Navy
        Me.labelVersion.Location = New System.Drawing.Point(1033, 17)
        Me.labelVersion.Name = "labelVersion"
        Me.labelVersion.Size = New System.Drawing.Size(16, 13)
        Me.labelVersion.TabIndex = 7
        Me.labelVersion.Text = "v."
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Navy
        Me.Label8.Location = New System.Drawing.Point(738, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(125, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "(EpsonFiscalInterface.dll)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Navy
        Me.Label7.Location = New System.Drawing.Point(698, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(210, 20)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "EPSON LATIN AMERICA"
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Location = New System.Drawing.Point(394, 13)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(93, 22)
        Me.btnDisconnect.TabIndex = 4
        Me.btnDisconnect.Text = "&Desconectar"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(291, 13)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(93, 22)
        Me.btnConnect.TabIndex = 3
        Me.btnConnect.Text = "&Conectar"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'cmbBaudRate
        '
        Me.cmbBaudRate.FormattingEnabled = True
        Me.cmbBaudRate.Items.AddRange(New Object() {"9600", "19200", "38400", "57600", "115200"})
        Me.cmbBaudRate.Location = New System.Drawing.Point(206, 13)
        Me.cmbBaudRate.Name = "cmbBaudRate"
        Me.cmbBaudRate.Size = New System.Drawing.Size(68, 21)
        Me.cmbBaudRate.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cmbBaudRate, "Cuando ""Puerto"" es USB (0) este parámetro no es considerado.")
        '
        'cmbPort
        '
        Me.cmbPort.FormattingEnabled = True
        Me.cmbPort.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cmbPort.Location = New System.Drawing.Point(63, 14)
        Me.cmbPort.Name = "cmbPort"
        Me.cmbPort.Size = New System.Drawing.Size(62, 21)
        Me.cmbPort.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmbPort, "Seleccione 0 para USB; 1 a N para COM1 a COMN.")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(145, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Velocidad: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Puerto: "
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(522, 12)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(93, 22)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "&Salir"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnZ)
        Me.GroupBox2.Controls.Add(Me.btnX)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 158)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(168, 48)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Cierres"
        '
        'btnZ
        '
        Me.btnZ.Location = New System.Drawing.Point(86, 17)
        Me.btnZ.Name = "btnZ"
        Me.btnZ.Size = New System.Drawing.Size(59, 25)
        Me.btnZ.TabIndex = 2
        Me.btnZ.Text = "Z"
        Me.btnZ.UseVisualStyleBackColor = True
        '
        'btnX
        '
        Me.btnX.Location = New System.Drawing.Point(21, 17)
        Me.btnX.Name = "btnX"
        Me.btnX.Size = New System.Drawing.Size(59, 25)
        Me.btnX.TabIndex = 1
        Me.btnX.Text = "X"
        Me.btnX.UseVisualStyleBackColor = True
        '
        'btnDllVersion
        '
        Me.btnDllVersion.Location = New System.Drawing.Point(21, 15)
        Me.btnDllVersion.Name = "btnDllVersion"
        Me.btnDllVersion.Size = New System.Drawing.Size(125, 30)
        Me.btnDllVersion.TabIndex = 3
        Me.btnDllVersion.Text = "&Versión de DLL"
        Me.btnDllVersion.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button3)
        Me.GroupBox3.Controls.Add(Me.btnErrorDescription)
        Me.GroupBox3.Controls.Add(Me.btnLastError)
        Me.GroupBox3.Controls.Add(Me.btnPrinterStatus)
        Me.GroupBox3.Controls.Add(Me.btnFiscalStatus)
        Me.GroupBox3.Controls.Add(Me.btnGetTypeStatus)
        Me.GroupBox3.Controls.Add(Me.cmbGetTypeStatus)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.btnOperatingMode)
        Me.GroupBox3.Controls.Add(Me.btnGetDateTime)
        Me.GroupBox3.Controls.Add(Me.btnFiscalDay)
        Me.GroupBox3.Controls.Add(Me.btnGetFPVersion)
        Me.GroupBox3.Controls.Add(Me.ShapeContainer1)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 207)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(168, 432)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Consultas"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(21, 55)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 30)
        Me.Button3.TabIndex = 20
        Me.Button3.Text = "Punto de Venta"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnErrorDescription
        '
        Me.btnErrorDescription.Location = New System.Drawing.Point(21, 393)
        Me.btnErrorDescription.Name = "btnErrorDescription"
        Me.btnErrorDescription.Size = New System.Drawing.Size(125, 28)
        Me.btnErrorDescription.TabIndex = 19
        Me.btnErrorDescription.Text = "Descripción de error"
        Me.btnErrorDescription.UseVisualStyleBackColor = True
        '
        'btnLastError
        '
        Me.btnLastError.Location = New System.Drawing.Point(21, 357)
        Me.btnLastError.Name = "btnLastError"
        Me.btnLastError.Size = New System.Drawing.Size(125, 28)
        Me.btnLastError.TabIndex = 18
        Me.btnLastError.Text = "Último error"
        Me.btnLastError.UseVisualStyleBackColor = True
        '
        'btnPrinterStatus
        '
        Me.btnPrinterStatus.Location = New System.Drawing.Point(21, 321)
        Me.btnPrinterStatus.Name = "btnPrinterStatus"
        Me.btnPrinterStatus.Size = New System.Drawing.Size(125, 28)
        Me.btnPrinterStatus.TabIndex = 17
        Me.btnPrinterStatus.Text = "Estado de Impresora"
        Me.btnPrinterStatus.UseVisualStyleBackColor = True
        '
        'btnFiscalStatus
        '
        Me.btnFiscalStatus.Location = New System.Drawing.Point(21, 285)
        Me.btnFiscalStatus.Name = "btnFiscalStatus"
        Me.btnFiscalStatus.Size = New System.Drawing.Size(125, 28)
        Me.btnFiscalStatus.TabIndex = 16
        Me.btnFiscalStatus.Text = "Estado Fiscal"
        Me.btnFiscalStatus.UseVisualStyleBackColor = True
        '
        'btnGetTypeStatus
        '
        Me.btnGetTypeStatus.Location = New System.Drawing.Point(21, 245)
        Me.btnGetTypeStatus.Name = "btnGetTypeStatus"
        Me.btnGetTypeStatus.Size = New System.Drawing.Size(125, 28)
        Me.btnGetTypeStatus.TabIndex = 14
        Me.btnGetTypeStatus.Text = "Tipo de Estado"
        Me.btnGetTypeStatus.UseVisualStyleBackColor = True
        '
        'cmbGetTypeStatus
        '
        Me.cmbGetTypeStatus.DropDownWidth = 400
        Me.cmbGetTypeStatus.FormattingEnabled = True
        Me.cmbGetTypeStatus.Items.AddRange(New Object() {"1003 - Documento en progreso", "1006 - Subestados", "1007 - Jornada fiscal", "1009 - Estado de memoria de transacciones", "1011 - Estado de memoria fiscal", "1012 - Modo técnico", "1013 - Estado de los certificados digitales", "1015 - Modo de funcionamiento del equipo", "7001 - Estado de la estación de Recibos (Receipt)", "7003 - Estado de la estación Journal", "7004 - Estación Slip – Sensor de validación de papel", "7005 - Estación Slip – Sensor de fin de carga de papel (TOF)", "7006 - Estación Slip – Sensor de inicio de carga de papel (BOF)", "7008 - Estación Slip/Validación – Sensor de espera de carga o remoción", "7010 - Estación de impresión seleccionada", "7012 - Cajon de dinero", "7013 - Tapa de la impresora", "7014 - Impresora con error", "7015 - Impresora en línea (online)", "9003 - Estado de la conexión"})
        Me.cmbGetTypeStatus.Location = New System.Drawing.Point(20, 220)
        Me.cmbGetTypeStatus.Name = "cmbGetTypeStatus"
        Me.cmbGetTypeStatus.Size = New System.Drawing.Size(126, 21)
        Me.cmbGetTypeStatus.TabIndex = 13
        Me.cmbGetTypeStatus.Text = "7001 - Estado de la estación de Recibos (Receipt)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(19, 205)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(122, 12)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "Seleccionar tipo de consulta:"
        '
        'btnOperatingMode
        '
        Me.btnOperatingMode.Location = New System.Drawing.Point(21, 127)
        Me.btnOperatingMode.Name = "btnOperatingMode"
        Me.btnOperatingMode.Size = New System.Drawing.Size(125, 30)
        Me.btnOperatingMode.TabIndex = 2
        Me.btnOperatingMode.Text = "Modo Func."
        Me.btnOperatingMode.UseVisualStyleBackColor = True
        '
        'btnGetDateTime
        '
        Me.btnGetDateTime.Location = New System.Drawing.Point(21, 91)
        Me.btnGetDateTime.Name = "btnGetDateTime"
        Me.btnGetDateTime.Size = New System.Drawing.Size(125, 30)
        Me.btnGetDateTime.TabIndex = 2
        Me.btnGetDateTime.Text = "Fecha / Hora"
        Me.btnGetDateTime.UseVisualStyleBackColor = True
        '
        'btnFiscalDay
        '
        Me.btnFiscalDay.Location = New System.Drawing.Point(21, 163)
        Me.btnFiscalDay.Name = "btnFiscalDay"
        Me.btnFiscalDay.Size = New System.Drawing.Size(125, 30)
        Me.btnFiscalDay.TabIndex = 1
        Me.btnFiscalDay.Text = "Estado Jornada"
        Me.btnFiscalDay.UseVisualStyleBackColor = True
        '
        'btnGetFPVersion
        '
        Me.btnGetFPVersion.Location = New System.Drawing.Point(21, 19)
        Me.btnGetFPVersion.Name = "btnGetFPVersion"
        Me.btnGetFPVersion.Size = New System.Drawing.Size(125, 30)
        Me.btnGetFPVersion.TabIndex = 0
        Me.btnGetFPVersion.Text = "Versión de IF"
        Me.btnGetFPVersion.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(3, 16)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(162, 413)
        Me.ShapeContainer1.TabIndex = 21
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.Location = New System.Drawing.Point(10, 187)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(138, 74)
        '
        'btnGetFiscalizationData
        '
        Me.btnGetFiscalizationData.Location = New System.Drawing.Point(9, 83)
        Me.btnGetFiscalizationData.Name = "btnGetFiscalizationData"
        Me.btnGetFiscalizationData.Size = New System.Drawing.Size(125, 30)
        Me.btnGetFiscalizationData.TabIndex = 1
        Me.btnGetFiscalizationData.Text = "Datos de Fiscalización"
        Me.btnGetFiscalizationData.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnPrefernces)
        Me.GroupBox4.Controls.Add(Me.cmbQueryOfDocInProgress)
        Me.GroupBox4.Controls.Add(Me.btnQueryOfDocInProgress)
        Me.GroupBox4.Controls.Add(Me.btnDocInProgress)
        Me.GroupBox4.Controls.Add(Me.btnDocNumberInProgress)
        Me.GroupBox4.Controls.Add(Me.btnSubtotalNet)
        Me.GroupBox4.Controls.Add(Me.btnSubtotalGross)
        Me.GroupBox4.Controls.Add(Me.btnOtherTax)
        Me.GroupBox4.Controls.Add(Me.btnDiscountByIVA)
        Me.GroupBox4.Controls.Add(Me.btnUpliftNegativeGlobal)
        Me.GroupBox4.Controls.Add(Me.btnDiscountGlobal)
        Me.GroupBox4.Controls.Add(Me.btnUpliftPositiveGlobal)
        Me.GroupBox4.Controls.Add(Me.cmbOpenVoucher)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.btnGetLastVoucherNumber)
        Me.GroupBox4.Controls.Add(Me.btnExtraDescription)
        Me.GroupBox4.Controls.Add(Me.btnItemDown)
        Me.GroupBox4.Controls.Add(Me.btnSubtotal)
        Me.GroupBox4.Controls.Add(Me.btnClose)
        Me.GroupBox4.Controls.Add(Me.btnPayment)
        Me.GroupBox4.Controls.Add(Me.btnItemUp)
        Me.GroupBox4.Controls.Add(Me.btnCancel)
        Me.GroupBox4.Controls.Add(Me.btnOpen)
        Me.GroupBox4.Location = New System.Drawing.Point(175, 47)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(170, 530)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Doc. fiscal y DNFH valorizado"
        '
        'btnPrefernces
        '
        Me.btnPrefernces.Enabled = False
        Me.btnPrefernces.Location = New System.Drawing.Point(9, 491)
        Me.btnPrefernces.Name = "btnPrefernces"
        Me.btnPrefernces.Size = New System.Drawing.Size(146, 28)
        Me.btnPrefernces.TabIndex = 22
        Me.btnPrefernces.Text = "Preferencia"
        Me.btnPrefernces.UseVisualStyleBackColor = True
        '
        'cmbQueryOfDocInProgress
        '
        Me.cmbQueryOfDocInProgress.Enabled = False
        Me.cmbQueryOfDocInProgress.FormattingEnabled = True
        Me.cmbQueryOfDocInProgress.Items.AddRange(New Object() {"83" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique", "81" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura A", "82" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura B", "91" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Remito ‘R’", "110" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito", "111" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura C", "112" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito A", "113" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito B", "114" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito C", "115" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito A", "116" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito B", "117" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito C", "118" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura M", "119" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito M", "120" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito M", "901" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Remito ‘X’", "902" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Recibo ‘X’", "903" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Presupuesto ‘X’", "907" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Comprobante Donación"})
        Me.cmbQueryOfDocInProgress.Location = New System.Drawing.Point(85, 395)
        Me.cmbQueryOfDocInProgress.Name = "cmbQueryOfDocInProgress"
        Me.cmbQueryOfDocInProgress.Size = New System.Drawing.Size(81, 21)
        Me.cmbQueryOfDocInProgress.TabIndex = 21
        '
        'btnQueryOfDocInProgress
        '
        Me.btnQueryOfDocInProgress.Enabled = False
        Me.btnQueryOfDocInProgress.Location = New System.Drawing.Point(9, 386)
        Me.btnQueryOfDocInProgress.Name = "btnQueryOfDocInProgress"
        Me.btnQueryOfDocInProgress.Size = New System.Drawing.Size(70, 30)
        Me.btnQueryOfDocInProgress.TabIndex = 20
        Me.btnQueryOfDocInProgress.Text = "Consultar:"
        Me.btnQueryOfDocInProgress.UseVisualStyleBackColor = True
        '
        'btnDocInProgress
        '
        Me.btnDocInProgress.Location = New System.Drawing.Point(9, 344)
        Me.btnDocInProgress.Name = "btnDocInProgress"
        Me.btnDocInProgress.Size = New System.Drawing.Size(70, 30)
        Me.btnDocInProgress.TabIndex = 0
        Me.btnDocInProgress.Text = "Tipo doc."
        Me.btnDocInProgress.UseVisualStyleBackColor = True
        '
        'btnDocNumberInProgress
        '
        Me.btnDocNumberInProgress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDocNumberInProgress.Location = New System.Drawing.Point(86, 345)
        Me.btnDocNumberInProgress.Name = "btnDocNumberInProgress"
        Me.btnDocNumberInProgress.Size = New System.Drawing.Size(69, 29)
        Me.btnDocNumberInProgress.TabIndex = 19
        Me.btnDocNumberInProgress.Text = "Núm. doc."
        Me.btnDocNumberInProgress.UseVisualStyleBackColor = True
        '
        'btnSubtotalNet
        '
        Me.btnSubtotalNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubtotalNet.Location = New System.Drawing.Point(86, 310)
        Me.btnSubtotalNet.Name = "btnSubtotalNet"
        Me.btnSubtotalNet.Size = New System.Drawing.Size(69, 29)
        Me.btnSubtotalNet.TabIndex = 17
        Me.btnSubtotalNet.Text = "SubtotalNeto"
        Me.btnSubtotalNet.UseVisualStyleBackColor = True
        '
        'btnSubtotalGross
        '
        Me.btnSubtotalGross.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubtotalGross.Location = New System.Drawing.Point(9, 310)
        Me.btnSubtotalGross.Name = "btnSubtotalGross"
        Me.btnSubtotalGross.Size = New System.Drawing.Size(70, 28)
        Me.btnSubtotalGross.TabIndex = 16
        Me.btnSubtotalGross.Text = "SubtotalBruto"
        Me.btnSubtotalGross.UseVisualStyleBackColor = True
        '
        'btnOtherTax
        '
        Me.btnOtherTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOtherTax.Location = New System.Drawing.Point(9, 242)
        Me.btnOtherTax.Name = "btnOtherTax"
        Me.btnOtherTax.Size = New System.Drawing.Size(70, 28)
        Me.btnOtherTax.TabIndex = 15
        Me.btnOtherTax.Text = "Otros tributos"
        Me.btnOtherTax.UseVisualStyleBackColor = True
        '
        'btnDiscountByIVA
        '
        Me.btnDiscountByIVA.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDiscountByIVA.Location = New System.Drawing.Point(87, 208)
        Me.btnDiscountByIVA.Name = "btnDiscountByIVA"
        Me.btnDiscountByIVA.Size = New System.Drawing.Size(69, 28)
        Me.btnDiscountByIVA.TabIndex = 14
        Me.btnDiscountByIVA.Text = "Desc. x IVA"
        Me.btnDiscountByIVA.UseVisualStyleBackColor = True
        '
        'btnUpliftNegativeGlobal
        '
        Me.btnUpliftNegativeGlobal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpliftNegativeGlobal.Location = New System.Drawing.Point(87, 174)
        Me.btnUpliftNegativeGlobal.Name = "btnUpliftNegativeGlobal"
        Me.btnUpliftNegativeGlobal.Size = New System.Drawing.Size(69, 28)
        Me.btnUpliftNegativeGlobal.TabIndex = 13
        Me.btnUpliftNegativeGlobal.Text = "Recargo-"
        Me.btnUpliftNegativeGlobal.UseVisualStyleBackColor = True
        '
        'btnDiscountGlobal
        '
        Me.btnDiscountGlobal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDiscountGlobal.Location = New System.Drawing.Point(9, 208)
        Me.btnDiscountGlobal.Name = "btnDiscountGlobal"
        Me.btnDiscountGlobal.Size = New System.Drawing.Size(70, 28)
        Me.btnDiscountGlobal.TabIndex = 12
        Me.btnDiscountGlobal.Text = "Descuento"
        Me.btnDiscountGlobal.UseVisualStyleBackColor = True
        '
        'btnUpliftPositiveGlobal
        '
        Me.btnUpliftPositiveGlobal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpliftPositiveGlobal.Location = New System.Drawing.Point(9, 174)
        Me.btnUpliftPositiveGlobal.Name = "btnUpliftPositiveGlobal"
        Me.btnUpliftPositiveGlobal.Size = New System.Drawing.Size(69, 28)
        Me.btnUpliftPositiveGlobal.TabIndex = 10
        Me.btnUpliftPositiveGlobal.Text = "Recargo+"
        Me.btnUpliftPositiveGlobal.UseVisualStyleBackColor = True
        '
        'cmbOpenVoucher
        '
        Me.cmbOpenVoucher.DropDownHeight = 270
        Me.cmbOpenVoucher.DropDownWidth = 200
        Me.cmbOpenVoucher.FormattingEnabled = True
        Me.cmbOpenVoucher.IntegralHeight = False
        Me.cmbOpenVoucher.Items.AddRange(New Object() {"83  - Tique", "81  - Tique Factura A", "82  - Tique Factura B", "91  - DNFH Remito ‘R’", "110 - Tique Nota de Crédito", "111 - Tique Factura C", "112 - Tique Nota de Crédito A", "113 - Tique Nota de Crédito B", "114 - Tique Nota de Crédito C", "115 - Tique Nota de Débito A", "116 - Tique Nota de Débito B", "117 - Tique Nota de Débito C", "118 - Tique Factura M", "119 - Tique Nota de Crédito M", "120 - Tique Nota de Débito M", "901 - DNFH Remito ‘X’", "902 - DNFH Recibo ‘X’", "903 - DNFH Presupuesto ‘X’", "907 - DNFH Comprobante Donación"})
        Me.cmbOpenVoucher.Location = New System.Drawing.Point(6, 41)
        Me.cmbOpenVoucher.Name = "cmbOpenVoucher"
        Me.cmbOpenVoucher.Size = New System.Drawing.Size(160, 21)
        Me.cmbOpenVoucher.TabIndex = 10
        Me.cmbOpenVoucher.Text = "83  - Tique"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(141, 12)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Seleccionar tipo de comprobante:"
        '
        'btnGetLastVoucherNumber
        '
        Me.btnGetLastVoucherNumber.Location = New System.Drawing.Point(9, 457)
        Me.btnGetLastVoucherNumber.Name = "btnGetLastVoucherNumber"
        Me.btnGetLastVoucherNumber.Size = New System.Drawing.Size(146, 28)
        Me.btnGetLastVoucherNumber.TabIndex = 8
        Me.btnGetLastVoucherNumber.Text = "Último doc. emitido"
        Me.btnGetLastVoucherNumber.UseVisualStyleBackColor = True
        '
        'btnExtraDescription
        '
        Me.btnExtraDescription.Location = New System.Drawing.Point(86, 72)
        Me.btnExtraDescription.Name = "btnExtraDescription"
        Me.btnExtraDescription.Size = New System.Drawing.Size(70, 28)
        Me.btnExtraDescription.TabIndex = 7
        Me.btnExtraDescription.Text = "Texto"
        Me.btnExtraDescription.UseVisualStyleBackColor = True
        '
        'btnItemDown
        '
        Me.btnItemDown.Location = New System.Drawing.Point(87, 106)
        Me.btnItemDown.Name = "btnItemDown"
        Me.btnItemDown.Size = New System.Drawing.Size(69, 28)
        Me.btnItemDown.TabIndex = 6
        Me.btnItemDown.Text = "Item-"
        Me.btnItemDown.UseVisualStyleBackColor = True
        '
        'btnSubtotal
        '
        Me.btnSubtotal.Location = New System.Drawing.Point(9, 140)
        Me.btnSubtotal.Name = "btnSubtotal"
        Me.btnSubtotal.Size = New System.Drawing.Size(69, 28)
        Me.btnSubtotal.TabIndex = 4
        Me.btnSubtotal.Text = "Subtotal"
        Me.btnSubtotal.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(9, 423)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(70, 28)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Cerrar"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnPayment
        '
        Me.btnPayment.Location = New System.Drawing.Point(9, 276)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.Size = New System.Drawing.Size(70, 28)
        Me.btnPayment.TabIndex = 3
        Me.btnPayment.Text = "Pago"
        Me.btnPayment.UseVisualStyleBackColor = True
        '
        'btnItemUp
        '
        Me.btnItemUp.Location = New System.Drawing.Point(9, 106)
        Me.btnItemUp.Name = "btnItemUp"
        Me.btnItemUp.Size = New System.Drawing.Size(70, 28)
        Me.btnItemUp.TabIndex = 2
        Me.btnItemUp.Text = "Item+"
        Me.btnItemUp.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(85, 423)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(70, 28)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancela"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOpen
        '
        Me.btnOpen.Location = New System.Drawing.Point(9, 71)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(70, 29)
        Me.btnOpen.TabIndex = 0
        Me.btnOpen.Text = "Abrir"
        Me.btnOpen.UseVisualStyleBackColor = True
        '
        'btnGetTrailer
        '
        Me.btnGetTrailer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetTrailer.Location = New System.Drawing.Point(185, 166)
        Me.btnGetTrailer.Name = "btnGetTrailer"
        Me.btnGetTrailer.Size = New System.Drawing.Size(146, 28)
        Me.btnGetTrailer.TabIndex = 26
        Me.btnGetTrailer.Text = "Leer cola"
        Me.btnGetTrailer.UseVisualStyleBackColor = True
        '
        'btnSetTrailer
        '
        Me.btnSetTrailer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetTrailer.Location = New System.Drawing.Point(185, 200)
        Me.btnSetTrailer.Name = "btnSetTrailer"
        Me.btnSetTrailer.Size = New System.Drawing.Size(146, 28)
        Me.btnSetTrailer.TabIndex = 25
        Me.btnSetTrailer.Text = "Establecer cola"
        Me.btnSetTrailer.UseVisualStyleBackColor = True
        '
        'btnGetHeader
        '
        Me.btnGetHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetHeader.Location = New System.Drawing.Point(8, 166)
        Me.btnGetHeader.Name = "btnGetHeader"
        Me.btnGetHeader.Size = New System.Drawing.Size(146, 28)
        Me.btnGetHeader.TabIndex = 24
        Me.btnGetHeader.Text = "Leer encabezado"
        Me.btnGetHeader.UseVisualStyleBackColor = True
        '
        'btnSetHeader
        '
        Me.btnSetHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSetHeader.Location = New System.Drawing.Point(8, 200)
        Me.btnSetHeader.Name = "btnSetHeader"
        Me.btnSetHeader.Size = New System.Drawing.Size(146, 28)
        Me.btnSetHeader.TabIndex = 23
        Me.btnSetHeader.Text = "Establecer encabezado"
        Me.btnSetHeader.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.Tag = "Test"
        '
        'btnLoadLogoBrowser
        '
        Me.btnLoadLogoBrowser.Location = New System.Drawing.Point(303, 19)
        Me.btnLoadLogoBrowser.Name = "btnLoadLogoBrowser"
        Me.btnLoadLogoBrowser.Size = New System.Drawing.Size(27, 28)
        Me.btnLoadLogoBrowser.TabIndex = 32
        Me.btnLoadLogoBrowser.Text = "..."
        Me.ToolTip1.SetToolTip(Me.btnLoadLogoBrowser, "Buscar logo de usuario a cargar")
        Me.btnLoadLogoBrowser.UseVisualStyleBackColor = True
        '
        'btnDownloadPeriodPending
        '
        Me.btnDownloadPeriodPending.Location = New System.Drawing.Point(9, 177)
        Me.btnDownloadPeriodPending.Name = "btnDownloadPeriodPending"
        Me.btnDownloadPeriodPending.Size = New System.Drawing.Size(125, 30)
        Me.btnDownloadPeriodPending.TabIndex = 11
        Me.btnDownloadPeriodPending.Text = "Descargar  período"
        Me.ToolTip1.SetToolTip(Me.btnDownloadPeriodPending, "Descargar período pendiente de descarga")
        Me.btnDownloadPeriodPending.UseVisualStyleBackColor = True
        '
        'btnDownloadPeriodDelete
        '
        Me.btnDownloadPeriodDelete.Location = New System.Drawing.Point(9, 212)
        Me.btnDownloadPeriodDelete.Name = "btnDownloadPeriodDelete"
        Me.btnDownloadPeriodDelete.Size = New System.Drawing.Size(125, 30)
        Me.btnDownloadPeriodDelete.TabIndex = 12
        Me.btnDownloadPeriodDelete.Text = "Confirmar descarga"
        Me.ToolTip1.SetToolTip(Me.btnDownloadPeriodDelete, "Permitir eliminación de las jornadas descargadas")
        Me.btnDownloadPeriodDelete.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(157, 179)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 30)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Ver XML de descarga"
        Me.ToolTip1.SetToolTip(Me.Button1, "Descargar período pendiente de descarga")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnCutPaper
        '
        Me.btnCutPaper.Location = New System.Drawing.Point(8, 54)
        Me.btnCutPaper.Name = "btnCutPaper"
        Me.btnCutPaper.Size = New System.Drawing.Size(146, 28)
        Me.btnCutPaper.TabIndex = 1
        Me.btnCutPaper.Text = "Cortar Papel"
        Me.btnCutPaper.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4, Me.progressLoadLogo})
        Me.StatusStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 642)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1134, 26)
        Me.StatusStrip1.TabIndex = 6
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(115, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(115, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(115, 17)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(115, 17)
        Me.ToolStripStatusLabel4.Text = "ToolStripStatusLabel4"
        '
        'progressLoadLogo
        '
        Me.progressLoadLogo.Name = "progressLoadLogo"
        Me.progressLoadLogo.Size = New System.Drawing.Size(100, 15)
        Me.progressLoadLogo.Step = 5
        Me.progressLoadLogo.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button1)
        Me.GroupBox5.Controls.Add(Me.btnDownloadGetInfo)
        Me.GroupBox5.Controls.Add(Me.btnDownloadPeriodDelete)
        Me.GroupBox5.Controls.Add(Me.btnDownloadPeriodPending)
        Me.GroupBox5.Controls.Add(Me.rdbtnByDate)
        Me.GroupBox5.Controls.Add(Me.txtTo_date)
        Me.GroupBox5.Controls.Add(Me.txtFrom_date)
        Me.GroupBox5.Controls.Add(Me.btnGetFiscalizationData)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.rdbtnByClosureZ)
        Me.GroupBox5.Controls.Add(Me.btnDownload)
        Me.GroupBox5.Controls.Add(Me.btnAudit)
        Me.GroupBox5.Controls.Add(Me.txtTo)
        Me.GroupBox5.Controls.Add(Me.txtFrom)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(525, 47)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(291, 287)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Reportes"
        '
        'btnDownloadGetInfo
        '
        Me.btnDownloadGetInfo.Location = New System.Drawing.Point(9, 247)
        Me.btnDownloadGetInfo.Name = "btnDownloadGetInfo"
        Me.btnDownloadGetInfo.Size = New System.Drawing.Size(125, 30)
        Me.btnDownloadGetInfo.TabIndex = 13
        Me.btnDownloadGetInfo.Text = "Consultar descargas"
        Me.btnDownloadGetInfo.UseVisualStyleBackColor = True
        '
        'rdbtnByDate
        '
        Me.rdbtnByDate.AutoSize = True
        Me.rdbtnByDate.Location = New System.Drawing.Point(147, 20)
        Me.rdbtnByDate.Name = "rdbtnByDate"
        Me.rdbtnByDate.Size = New System.Drawing.Size(73, 17)
        Me.rdbtnByDate.TabIndex = 10
        Me.rdbtnByDate.Text = "por Fecha"
        Me.rdbtnByDate.UseVisualStyleBackColor = True
        '
        'txtTo_date
        '
        Me.txtTo_date.Location = New System.Drawing.Point(225, 53)
        Me.txtTo_date.Name = "txtTo_date"
        Me.txtTo_date.Size = New System.Drawing.Size(51, 20)
        Me.txtTo_date.TabIndex = 9
        Me.txtTo_date.Text = "070917"
        '
        'txtFrom_date
        '
        Me.txtFrom_date.Location = New System.Drawing.Point(225, 33)
        Me.txtFrom_date.Name = "txtFrom_date"
        Me.txtFrom_date.Size = New System.Drawing.Size(51, 20)
        Me.txtFrom_date.TabIndex = 8
        Me.txtFrom_date.Text = "010917"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(176, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 13)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "final:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(176, 38)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(36, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "inicial:"
        '
        'rdbtnByClosureZ
        '
        Me.rdbtnByClosureZ.AutoSize = True
        Me.rdbtnByClosureZ.Checked = True
        Me.rdbtnByClosureZ.Location = New System.Drawing.Point(9, 20)
        Me.rdbtnByClosureZ.Name = "rdbtnByClosureZ"
        Me.rdbtnByClosureZ.Size = New System.Drawing.Size(80, 17)
        Me.rdbtnByClosureZ.TabIndex = 5
        Me.rdbtnByClosureZ.TabStop = True
        Me.rdbtnByClosureZ.Text = "por Cierre Z"
        Me.rdbtnByClosureZ.UseVisualStyleBackColor = True
        '
        'btnDownload
        '
        Me.btnDownload.Location = New System.Drawing.Point(157, 145)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(125, 30)
        Me.btnDownload.TabIndex = 4
        Me.btnDownload.Text = "Descargar"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'btnAudit
        '
        Me.btnAudit.Location = New System.Drawing.Point(157, 111)
        Me.btnAudit.Name = "btnAudit"
        Me.btnAudit.Size = New System.Drawing.Size(125, 30)
        Me.btnAudit.TabIndex = 3
        Me.btnAudit.Text = "Auditar Resumen"
        Me.btnAudit.UseVisualStyleBackColor = True
        '
        'txtTo
        '
        Me.txtTo.Location = New System.Drawing.Point(90, 56)
        Me.txtTo.Name = "txtTo"
        Me.txtTo.Size = New System.Drawing.Size(51, 20)
        Me.txtTo.TabIndex = 3
        Me.txtTo.Text = "5"
        '
        'txtFrom
        '
        Me.txtFrom.Location = New System.Drawing.Point(90, 35)
        Me.txtFrom.Name = "txtFrom"
        Me.txtFrom.Size = New System.Drawing.Size(51, 20)
        Me.txtFrom.TabIndex = 2
        Me.txtFrom.Text = "1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(38, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "final:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "inicial:"
        '
        'btnLoadLogo
        '
        Me.btnLoadLogo.Location = New System.Drawing.Point(186, 19)
        Me.btnLoadLogo.Name = "btnLoadLogo"
        Me.btnLoadLogo.Size = New System.Drawing.Size(113, 28)
        Me.btnLoadLogo.TabIndex = 5
        Me.btnLoadLogo.Text = "Cargar Logo"
        Me.btnLoadLogo.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.btnLoadLogoBrowser)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.txtHeaderTrailerDescription)
        Me.GroupBox6.Controls.Add(Me.cmbHeaderTrailerNumber)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Controls.Add(Me.btnGetTrailer)
        Me.GroupBox6.Controls.Add(Me.btnDeleteLogo)
        Me.GroupBox6.Controls.Add(Me.btnSetTrailer)
        Me.GroupBox6.Controls.Add(Me.btnLoadLogo)
        Me.GroupBox6.Controls.Add(Me.btnGetHeader)
        Me.GroupBox6.Controls.Add(Me.btnCutPaper)
        Me.GroupBox6.Controls.Add(Me.btnSetHeader)
        Me.GroupBox6.Controls.Add(Me.btnFeedPaper)
        Me.GroupBox6.Controls.Add(Me.ShapeContainer2)
        Me.GroupBox6.Location = New System.Drawing.Point(351, 338)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(341, 239)
        Me.GroupBox6.TabIndex = 8
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Acciones"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(16, 141)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(103, 12)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Texto encabezado/cola:"
        '
        'txtHeaderTrailerDescription
        '
        Me.txtHeaderTrailerDescription.Location = New System.Drawing.Point(125, 136)
        Me.txtHeaderTrailerDescription.Name = "txtHeaderTrailerDescription"
        Me.txtHeaderTrailerDescription.Size = New System.Drawing.Size(206, 20)
        Me.txtHeaderTrailerDescription.TabIndex = 29
        Me.txtHeaderTrailerDescription.Text = " Descripción de encabezado o cola"
        '
        'cmbHeaderTrailerNumber
        '
        Me.cmbHeaderTrailerNumber.FormattingEnabled = True
        Me.cmbHeaderTrailerNumber.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"})
        Me.cmbHeaderTrailerNumber.Location = New System.Drawing.Point(125, 109)
        Me.cmbHeaderTrailerNumber.Name = "cmbHeaderTrailerNumber"
        Me.cmbHeaderTrailerNumber.Size = New System.Drawing.Size(206, 21)
        Me.cmbHeaderTrailerNumber.TabIndex = 28
        Me.cmbHeaderTrailerNumber.Text = "1"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(6, 113)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(113, 12)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "Número encabezado/cola:"
        '
        'btnDeleteLogo
        '
        Me.btnDeleteLogo.Location = New System.Drawing.Point(185, 55)
        Me.btnDeleteLogo.Name = "btnDeleteLogo"
        Me.btnDeleteLogo.Size = New System.Drawing.Size(146, 28)
        Me.btnDeleteLogo.TabIndex = 6
        Me.btnDeleteLogo.Text = "Borrar Logo"
        Me.btnDeleteLogo.UseVisualStyleBackColor = True
        '
        'btnFeedPaper
        '
        Me.btnFeedPaper.Location = New System.Drawing.Point(7, 18)
        Me.btnFeedPaper.Name = "btnFeedPaper"
        Me.btnFeedPaper.Size = New System.Drawing.Size(146, 28)
        Me.btnFeedPaper.TabIndex = 0
        Me.btnFeedPaper.Text = "Avanzar Papel"
        Me.btnFeedPaper.UseVisualStyleBackColor = True
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(3, 16)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(335, 220)
        Me.ShapeContainer2.TabIndex = 31
        Me.ShapeContainer2.TabStop = False
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 8
        Me.LineShape1.X2 = 328
        Me.LineShape1.Y1 = 79
        Me.LineShape1.Y2 = 79
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button4)
        Me.GroupBox7.Controls.Add(Me.ctrlRichTextBoxLog)
        Me.GroupBox7.Location = New System.Drawing.Point(822, 47)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(310, 593)
        Me.GroupBox7.TabIndex = 5
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Log"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 557)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(304, 30)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "Borrar log"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ctrlRichTextBoxLog
        '
        Me.ctrlRichTextBoxLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ctrlRichTextBoxLog.Font = New System.Drawing.Font("Lucida Console", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ctrlRichTextBoxLog.Location = New System.Drawing.Point(2, 14)
        Me.ctrlRichTextBoxLog.Name = "ctrlRichTextBoxLog"
        Me.ctrlRichTextBoxLog.ReadOnly = True
        Me.ctrlRichTextBoxLog.Size = New System.Drawing.Size(304, 539)
        Me.ctrlRichTextBoxLog.TabIndex = 0
        Me.ctrlRichTextBoxLog.Text = ""
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.btnCancel_DNFH)
        Me.GroupBox8.Controls.Add(Me.btnPrefernces_DNFH)
        Me.GroupBox8.Controls.Add(Me.Label11)
        Me.GroupBox8.Controls.Add(Me.cmbQueryOfDocInProgress_DNFH)
        Me.GroupBox8.Controls.Add(Me.btnQueryOfDocInProgress_DNFH)
        Me.GroupBox8.Controls.Add(Me.Label10)
        Me.GroupBox8.Controls.Add(Me.btnGetLastVoucherNumber_DNFH)
        Me.GroupBox8.Controls.Add(Me.btnClose_DNFH)
        Me.GroupBox8.Controls.Add(Me.btn_MultiFreeLine_DNFH)
        Me.GroupBox8.Controls.Add(Me.btnOpen_DNFH)
        Me.GroupBox8.Controls.Add(Me.btnFreeLine_DNFH)
        Me.GroupBox8.Controls.Add(Me.cmbOpenVoucherDNFH)
        Me.GroupBox8.Controls.Add(Me.Label6)
        Me.GroupBox8.Location = New System.Drawing.Point(351, 47)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(168, 287)
        Me.GroupBox8.TabIndex = 9
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "DNFH"
        '
        'btnCancel_DNFH
        '
        Me.btnCancel_DNFH.Location = New System.Drawing.Point(84, 178)
        Me.btnCancel_DNFH.Name = "btnCancel_DNFH"
        Me.btnCancel_DNFH.Size = New System.Drawing.Size(70, 28)
        Me.btnCancel_DNFH.TabIndex = 36
        Me.btnCancel_DNFH.Text = "Cancela"
        Me.btnCancel_DNFH.UseVisualStyleBackColor = True
        '
        'btnPrefernces_DNFH
        '
        Me.btnPrefernces_DNFH.Enabled = False
        Me.btnPrefernces_DNFH.Location = New System.Drawing.Point(7, 246)
        Me.btnPrefernces_DNFH.Name = "btnPrefernces_DNFH"
        Me.btnPrefernces_DNFH.Size = New System.Drawing.Size(146, 28)
        Me.btnPrefernces_DNFH.TabIndex = 35
        Me.btnPrefernces_DNFH.Text = "Preferencia"
        Me.btnPrefernces_DNFH.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Enabled = False
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(83, 138)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 12)
        Me.Label11.TabIndex = 34
        Me.Label11.Text = "Tipo de consulta:"
        '
        'cmbQueryOfDocInProgress_DNFH
        '
        Me.cmbQueryOfDocInProgress_DNFH.Enabled = False
        Me.cmbQueryOfDocInProgress_DNFH.FormattingEnabled = True
        Me.cmbQueryOfDocInProgress_DNFH.Items.AddRange(New Object() {"83" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique", "81" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura A", "82" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura B", "91" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Remito ‘R’", "110" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito", "111" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura C", "112" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito A", "113" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito B", "114" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito C", "115" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito A", "116" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito B", "117" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito C", "118" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Factura M", "119" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Crédito M", "120" & Global.Microsoft.VisualBasic.ChrW(9) & "- Tique Nota de Débito M", "901" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Remito ‘X’", "902" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Recibo ‘X’", "903" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Presupuesto ‘X’", "907" & Global.Microsoft.VisualBasic.ChrW(9) & "- DNFH Comprobante Donación"})
        Me.cmbQueryOfDocInProgress_DNFH.Location = New System.Drawing.Point(83, 151)
        Me.cmbQueryOfDocInProgress_DNFH.Name = "cmbQueryOfDocInProgress_DNFH"
        Me.cmbQueryOfDocInProgress_DNFH.Size = New System.Drawing.Size(81, 21)
        Me.cmbQueryOfDocInProgress_DNFH.TabIndex = 31
        '
        'btnQueryOfDocInProgress_DNFH
        '
        Me.btnQueryOfDocInProgress_DNFH.Enabled = False
        Me.btnQueryOfDocInProgress_DNFH.Location = New System.Drawing.Point(7, 142)
        Me.btnQueryOfDocInProgress_DNFH.Name = "btnQueryOfDocInProgress_DNFH"
        Me.btnQueryOfDocInProgress_DNFH.Size = New System.Drawing.Size(70, 30)
        Me.btnQueryOfDocInProgress_DNFH.TabIndex = 29
        Me.btnQueryOfDocInProgress_DNFH.Text = "Consultar:"
        Me.btnQueryOfDocInProgress_DNFH.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Enabled = False
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(258, 216)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 12)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "Tipo de consulta:"
        '
        'btnGetLastVoucherNumber_DNFH
        '
        Me.btnGetLastVoucherNumber_DNFH.Location = New System.Drawing.Point(7, 212)
        Me.btnGetLastVoucherNumber_DNFH.Name = "btnGetLastVoucherNumber_DNFH"
        Me.btnGetLastVoucherNumber_DNFH.Size = New System.Drawing.Size(146, 28)
        Me.btnGetLastVoucherNumber_DNFH.TabIndex = 28
        Me.btnGetLastVoucherNumber_DNFH.Text = "Último doc. emitido"
        Me.btnGetLastVoucherNumber_DNFH.UseVisualStyleBackColor = True
        '
        'btnClose_DNFH
        '
        Me.btnClose_DNFH.Location = New System.Drawing.Point(7, 178)
        Me.btnClose_DNFH.Name = "btnClose_DNFH"
        Me.btnClose_DNFH.Size = New System.Drawing.Size(70, 28)
        Me.btnClose_DNFH.TabIndex = 27
        Me.btnClose_DNFH.Text = "Cerrar"
        Me.btnClose_DNFH.UseVisualStyleBackColor = True
        '
        'btn_MultiFreeLine_DNFH
        '
        Me.btn_MultiFreeLine_DNFH.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_MultiFreeLine_DNFH.Location = New System.Drawing.Point(83, 107)
        Me.btn_MultiFreeLine_DNFH.Name = "btn_MultiFreeLine_DNFH"
        Me.btn_MultiFreeLine_DNFH.Size = New System.Drawing.Size(70, 28)
        Me.btn_MultiFreeLine_DNFH.TabIndex = 15
        Me.btn_MultiFreeLine_DNFH.Text = "Multiplelíneas"
        Me.btn_MultiFreeLine_DNFH.UseVisualStyleBackColor = True
        '
        'btnOpen_DNFH
        '
        Me.btnOpen_DNFH.Location = New System.Drawing.Point(7, 73)
        Me.btnOpen_DNFH.Name = "btnOpen_DNFH"
        Me.btnOpen_DNFH.Size = New System.Drawing.Size(70, 29)
        Me.btnOpen_DNFH.TabIndex = 14
        Me.btnOpen_DNFH.Text = "Abrir"
        Me.btnOpen_DNFH.UseVisualStyleBackColor = True
        '
        'btnFreeLine_DNFH
        '
        Me.btnFreeLine_DNFH.Location = New System.Drawing.Point(7, 107)
        Me.btnFreeLine_DNFH.Name = "btnFreeLine_DNFH"
        Me.btnFreeLine_DNFH.Size = New System.Drawing.Size(70, 28)
        Me.btnFreeLine_DNFH.TabIndex = 13
        Me.btnFreeLine_DNFH.Text = "Texto libre"
        Me.btnFreeLine_DNFH.UseVisualStyleBackColor = True
        '
        'cmbOpenVoucherDNFH
        '
        Me.cmbOpenVoucherDNFH.DropDownWidth = 200
        Me.cmbOpenVoucherDNFH.FormattingEnabled = True
        Me.cmbOpenVoucherDNFH.IntegralHeight = False
        Me.cmbOpenVoucherDNFH.Items.AddRange(New Object() {"910 - DNFH Documento Genérico", "950 - DNFH Documento de Uso Interno"})
        Me.cmbOpenVoucherDNFH.Location = New System.Drawing.Point(4, 41)
        Me.cmbOpenVoucherDNFH.Name = "cmbOpenVoucherDNFH"
        Me.cmbOpenVoucherDNFH.Size = New System.Drawing.Size(160, 21)
        Me.cmbOpenVoucherDNFH.TabIndex = 12
        Me.cmbOpenVoucherDNFH.Text = "910 - DNFH Documento Genérico"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(141, 12)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Seleccionar tipo de comprobante:"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_get_qty_output_fields)
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_get_return_code)
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_get_printer_status)
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_get_fiscal_status)
        Me.GroupBox9.Controls.Add(Me.Button2)
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_TechnicalTticket)
        Me.GroupBox9.Controls.Add(Me.btnGenericCommand_X)
        Me.GroupBox9.Location = New System.Drawing.Point(175, 578)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(641, 61)
        Me.GroupBox9.TabIndex = 10
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Comando genérico"
        '
        'btnGenericCommand_get_qty_output_fields
        '
        Me.btnGenericCommand_get_qty_output_fields.Location = New System.Drawing.Point(517, 34)
        Me.btnGenericCommand_get_qty_output_fields.Name = "btnGenericCommand_get_qty_output_fields"
        Me.btnGenericCommand_get_qty_output_fields.Size = New System.Drawing.Size(115, 21)
        Me.btnGenericCommand_get_qty_output_fields.TabIndex = 9
        Me.btnGenericCommand_get_qty_output_fields.Text = "Cant. campos salida"
        Me.btnGenericCommand_get_qty_output_fields.UseVisualStyleBackColor = True
        '
        'btnGenericCommand_get_return_code
        '
        Me.btnGenericCommand_get_return_code.Location = New System.Drawing.Point(517, 10)
        Me.btnGenericCommand_get_return_code.Name = "btnGenericCommand_get_return_code"
        Me.btnGenericCommand_get_return_code.Size = New System.Drawing.Size(115, 21)
        Me.btnGenericCommand_get_return_code.TabIndex = 8
        Me.btnGenericCommand_get_return_code.Text = "Código de retorno"
        Me.btnGenericCommand_get_return_code.UseVisualStyleBackColor = True
        '
        'btnGenericCommand_get_printer_status
        '
        Me.btnGenericCommand_get_printer_status.Location = New System.Drawing.Point(382, 34)
        Me.btnGenericCommand_get_printer_status.Name = "btnGenericCommand_get_printer_status"
        Me.btnGenericCommand_get_printer_status.Size = New System.Drawing.Size(115, 21)
        Me.btnGenericCommand_get_printer_status.TabIndex = 7
        Me.btnGenericCommand_get_printer_status.Text = "Estado impresora"
        Me.btnGenericCommand_get_printer_status.UseVisualStyleBackColor = True
        '
        'btnGenericCommand_get_fiscal_status
        '
        Me.btnGenericCommand_get_fiscal_status.Location = New System.Drawing.Point(382, 10)
        Me.btnGenericCommand_get_fiscal_status.Name = "btnGenericCommand_get_fiscal_status"
        Me.btnGenericCommand_get_fiscal_status.Size = New System.Drawing.Size(115, 21)
        Me.btnGenericCommand_get_fiscal_status.TabIndex = 6
        Me.btnGenericCommand_get_fiscal_status.Text = "Estado fiscal"
        Me.btnGenericCommand_get_fiscal_status.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(250, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(115, 30)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Información Jornada"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'btnGenericCommand_TechnicalTticket
        '
        Me.btnGenericCommand_TechnicalTticket.Location = New System.Drawing.Point(129, 19)
        Me.btnGenericCommand_TechnicalTticket.Name = "btnGenericCommand_TechnicalTticket"
        Me.btnGenericCommand_TechnicalTticket.Size = New System.Drawing.Size(115, 30)
        Me.btnGenericCommand_TechnicalTticket.TabIndex = 4
        Me.btnGenericCommand_TechnicalTticket.Text = "Tique técnico"
        Me.btnGenericCommand_TechnicalTticket.UseVisualStyleBackColor = True
        '
        'btnGenericCommand_X
        '
        Me.btnGenericCommand_X.Location = New System.Drawing.Point(8, 19)
        Me.btnGenericCommand_X.Name = "btnGenericCommand_X"
        Me.btnGenericCommand_X.Size = New System.Drawing.Size(115, 30)
        Me.btnGenericCommand_X.TabIndex = 3
        Me.btnGenericCommand_X.Text = "X  (con preferencias)"
        Me.btnGenericCommand_X.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.btnDllVersion)
        Me.GroupBox10.Location = New System.Drawing.Point(3, 47)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(168, 51)
        Me.GroupBox10.TabIndex = 11
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Sin conexión"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Enabled = False
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(260, 427)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 12)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Tipo de consulta:"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.btnDateTimeNewSet)
        Me.GroupBox11.Controls.Add(Me.Label17)
        Me.GroupBox11.Controls.Add(Me.LblDateTimeNew)
        Me.GroupBox11.Controls.Add(Me.btnDateTimeSync)
        Me.GroupBox11.Controls.Add(Me.btnDateTimeGet)
        Me.GroupBox11.Location = New System.Drawing.Point(698, 338)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(118, 239)
        Me.GroupBox11.TabIndex = 22
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Fecha y Hora"
        '
        'btnDateTimeNewSet
        '
        Me.btnDateTimeNewSet.Location = New System.Drawing.Point(6, 165)
        Me.btnDateTimeNewSet.Name = "btnDateTimeNewSet"
        Me.btnDateTimeNewSet.Size = New System.Drawing.Size(106, 30)
        Me.btnDateTimeNewSet.TabIndex = 11
        Me.btnDateTimeNewSet.Text = "Establecer"
        Me.btnDateTimeNewSet.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(3, 120)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(104, 13)
        Me.Label17.TabIndex = 10
        Me.Label17.Text = "Nueva fecha y hora:"
        '
        'LblDateTimeNew
        '
        Me.LblDateTimeNew.Location = New System.Drawing.Point(23, 136)
        Me.LblDateTimeNew.Name = "LblDateTimeNew"
        Me.LblDateTimeNew.Size = New System.Drawing.Size(89, 20)
        Me.LblDateTimeNew.TabIndex = 9
        Me.LblDateTimeNew.Text = "010917T225803"
        '
        'btnDateTimeSync
        '
        Me.btnDateTimeSync.Location = New System.Drawing.Point(6, 53)
        Me.btnDateTimeSync.Name = "btnDateTimeSync"
        Me.btnDateTimeSync.Size = New System.Drawing.Size(106, 30)
        Me.btnDateTimeSync.TabIndex = 4
        Me.btnDateTimeSync.Text = "Sincronizar"
        Me.btnDateTimeSync.UseVisualStyleBackColor = True
        '
        'btnDateTimeGet
        '
        Me.btnDateTimeGet.Location = New System.Drawing.Point(6, 18)
        Me.btnDateTimeGet.Name = "btnDateTimeGet"
        Me.btnDateTimeGet.Size = New System.Drawing.Size(106, 30)
        Me.btnDateTimeGet.TabIndex = 3
        Me.btnDateTimeGet.Text = "Consultar"
        Me.btnDateTimeGet.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.btnShowLog)
        Me.GroupBox12.Controls.Add(Me.chckEnable)
        Me.GroupBox12.Location = New System.Drawing.Point(3, 98)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(168, 59)
        Me.GroupBox12.TabIndex = 23
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Log de comunicación"
        '
        'chckEnable
        '
        Me.chckEnable.AutoSize = True
        Me.chckEnable.Checked = True
        Me.chckEnable.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chckEnable.Location = New System.Drawing.Point(14, 25)
        Me.chckEnable.Name = "chckEnable"
        Me.chckEnable.Size = New System.Drawing.Size(85, 17)
        Me.chckEnable.TabIndex = 0
        Me.chckEnable.Text = "Habilitar Log"
        Me.chckEnable.UseVisualStyleBackColor = True
        '
        'btnShowLog
        '
        Me.btnShowLog.Location = New System.Drawing.Point(118, 21)
        Me.btnShowLog.Name = "btnShowLog"
        Me.btnShowLog.Size = New System.Drawing.Size(27, 21)
        Me.btnShowLog.TabIndex = 33
        Me.btnShowLog.Text = "..."
        Me.ToolTip1.SetToolTip(Me.btnShowLog, "Mostrar archivo de log")
        Me.btnShowLog.UseVisualStyleBackColor = True
        '
        'FormInit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1134, 668)
        Me.Controls.Add(Me.GroupBox12)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "FormInit"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ejemplo VB .NET Lib Epson Alto Nivel | EpsonFiscalInterface"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbBaudRate As System.Windows.Forms.ComboBox
    Friend WithEvents cmbPort As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnZ As System.Windows.Forms.Button
    Friend WithEvents btnX As System.Windows.Forms.Button
    Friend WithEvents btnDllVersion As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnGetFPVersion As System.Windows.Forms.Button
    Friend WithEvents btnGetFiscalizationData As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnOpen As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnGetDateTime As System.Windows.Forms.Button
    Friend WithEvents btnPayment As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnSubtotal As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents btnItemUp As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnItemDown As System.Windows.Forms.Button
    Friend WithEvents btnExtraDescription As System.Windows.Forms.Button
    Friend WithEvents btnDisconnect As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDownload As System.Windows.Forms.Button
    Friend WithEvents btnAudit As System.Windows.Forms.Button
    Friend WithEvents txtTo As System.Windows.Forms.TextBox
    Friend WithEvents txtFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCutPaper As System.Windows.Forms.Button
    Friend WithEvents btnFeedPaper As System.Windows.Forms.Button
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents btnOperatingMode As System.Windows.Forms.Button
    Friend WithEvents btnFiscalDay As System.Windows.Forms.Button
    Friend WithEvents btnDocInProgress As System.Windows.Forms.Button
    Friend WithEvents btnLoadLogo As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDeleteLogo As System.Windows.Forms.Button
    Friend WithEvents btnGetLastVoucherNumber As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents btnGenericCommand_X As System.Windows.Forms.Button
    Friend WithEvents cmbOpenVoucher As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnUpliftPositiveGlobal As System.Windows.Forms.Button
    Friend WithEvents btnOtherTax As System.Windows.Forms.Button
    Friend WithEvents btnDiscountByIVA As System.Windows.Forms.Button
    Friend WithEvents btnUpliftNegativeGlobal As System.Windows.Forms.Button
    Friend WithEvents btnDiscountGlobal As System.Windows.Forms.Button
    Friend WithEvents btnDocNumberInProgress As System.Windows.Forms.Button
    Friend WithEvents btnSubtotalNet As System.Windows.Forms.Button
    Friend WithEvents btnSubtotalGross As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbOpenVoucherDNFH As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbQueryOfDocInProgress As System.Windows.Forms.ComboBox
    Friend WithEvents btnQueryOfDocInProgress As System.Windows.Forms.Button
    Friend WithEvents btn_MultiFreeLine_DNFH As System.Windows.Forms.Button
    Friend WithEvents btnOpen_DNFH As System.Windows.Forms.Button
    Friend WithEvents btnFreeLine_DNFH As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnPrefernces As System.Windows.Forms.Button
    Friend WithEvents btnGetHeader As System.Windows.Forms.Button
    Friend WithEvents btnSetHeader As System.Windows.Forms.Button
    Friend WithEvents btnGetTrailer As System.Windows.Forms.Button
    Friend WithEvents btnSetTrailer As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmbQueryOfDocInProgress_DNFH As System.Windows.Forms.ComboBox
    Friend WithEvents btnQueryOfDocInProgress_DNFH As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnGetLastVoucherNumber_DNFH As System.Windows.Forms.Button
    Friend WithEvents btnClose_DNFH As System.Windows.Forms.Button
    Friend WithEvents btnPrefernces_DNFH As System.Windows.Forms.Button
    Friend WithEvents cmbGetTypeStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnGetTypeStatus As System.Windows.Forms.Button
    Friend WithEvents btnPrinterStatus As System.Windows.Forms.Button
    Friend WithEvents btnFiscalStatus As System.Windows.Forms.Button
    Friend WithEvents btnErrorDescription As System.Windows.Forms.Button
    Friend WithEvents btnLastError As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents rdbtnByDate As System.Windows.Forms.RadioButton
    Friend WithEvents txtTo_date As System.Windows.Forms.TextBox
    Friend WithEvents txtFrom_date As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents rdbtnByClosureZ As System.Windows.Forms.RadioButton
    Friend WithEvents ctrlRichTextBoxLog As System.Windows.Forms.RichTextBox
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents labelVersion As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtHeaderTrailerDescription As System.Windows.Forms.TextBox
    Friend WithEvents cmbHeaderTrailerNumber As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents progressLoadLogo As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents btnGenericCommand_TechnicalTticket As System.Windows.Forms.Button
    Friend WithEvents btnLoadLogoBrowser As System.Windows.Forms.Button
    Friend WithEvents btnCancel_DNFH As System.Windows.Forms.Button
    Friend WithEvents btnDownloadPeriodPending As System.Windows.Forms.Button
    Friend WithEvents btnDownloadGetInfo As System.Windows.Forms.Button
    Friend WithEvents btnDownloadPeriodDelete As System.Windows.Forms.Button
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LblDateTimeNew As System.Windows.Forms.TextBox
    Friend WithEvents btnDateTimeSync As System.Windows.Forms.Button
    Friend WithEvents btnDateTimeGet As System.Windows.Forms.Button
    Friend WithEvents btnDateTimeNewSet As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents btnGenericCommand_get_qty_output_fields As System.Windows.Forms.Button
    Friend WithEvents btnGenericCommand_get_return_code As System.Windows.Forms.Button
    Friend WithEvents btnGenericCommand_get_printer_status As System.Windows.Forms.Button
    Friend WithEvents btnGenericCommand_get_fiscal_status As System.Windows.Forms.Button
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents chckEnable As System.Windows.Forms.CheckBox
    Friend WithEvents btnShowLog As System.Windows.Forms.Button

End Class
