****************************************************
     Parallel Driver Cleaning Tool
            - Quick Guide -

     Copyright (C) 2000-2003 NITGEN Co., Ltd.
****************************************************


This tool removes NITGEN drivers of FDP01 and FDP02 device installed.

This applies to:

  - Windows NT 4.0
  - Windows 2000
  - Windows XP


-----------------------
 Instruction for use
-----------------------
1. Run this tool: CleaningTool.exe.

2. Click "Remove" button.

3. One of messages belows shows up according to the state of drivers.

   The driver is not running.
   The driver is starting.
   The driver is stopping.
   The driver is running.
   The driver continue is pending.
   The driver pause is pending.
   The driver is paused.
   The driver is unknown state.

4. Reboot the system.

- End of Doc -